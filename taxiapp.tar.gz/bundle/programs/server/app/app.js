var require = meteorInstall({"imports":{"api":{"google":{"Settings.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/google/Settings.js                                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
const key = require('./taxiapp-60d0eb253959.json').private_key;

const SERVICE_ACCT_ID = 'taxiapp@taxiapp-200711.iam.gserviceaccount.com';
const CALENDAR_URL = 'https://calendar.google.com/calendar/b/2?cid=aW5mby50aGlqbS5lY3NAZ21haWwuY29t';
const CALENDAR_ID = {
  'primary': 'info.thijm.ecs@gmail.com'
};
const TIMEZONE = 'GMT+02:00';
module.exports.calendarUrl = CALENDAR_URL;
module.exports.serviceAcctId = SERVICE_ACCT_ID;
module.exports.calendarId = CALENDAR_ID;
module.exports.key = key;
module.exports.timezone = TIMEZONE;
////////////////////////////////////////////////////////////////////////////////////////////////////////

},"taxiapp-60d0eb253959.json":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/google/taxiapp-60d0eb253959.json                                                       //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.exports = {
  "type": "service_account",
  "project_id": "taxiapp-200711",
  "private_key_id": "60d0eb25395967b457f13aacd3ea1a179822640d",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCTuMCg7rpChsAH\nKYyKsiIl9DURB3R95IBe2qHfAkIIRAGaVR629aYOEfJrDR8cmsnzATJzeZxq9V49\njW+rhPagHvOg5GWt+ZCBeOYUvTjQ/Ho3ys9tKIdkGH/CmWvL5JQLLLXLojuUqz2v\npGzjlZsha0ln2M0Ujtosx2Md6GGw4hZ2fFfUsJTY78uSxhDgt3tYDZhyzseVKXc9\ngd0Pny1A67mZRNRMKYieRMyNdvtYolCcWUWk0b4komKhx7/RRFlzfBo9qPYUxMXZ\n/mD5HIjB4DKtx/6pSPSQLsUW7J1oRZM0hzSqSk9E8rrKPJLz7Qtox7nadBWX4ir6\nhnOFT+k1AgMBAAECggEACIbBsZhN7nCWLWOnzcqd33hyxq6aOfkCMtdmP/fCpXT9\nbbHLkc5ofQfqqOSrPsytauYPCizDC0Zp394ly63jSVc4Azmjp9DPlzWJ/Dj2ylNE\nX6uIYPnVpMCoQSx3VR+2rtVwEdalnz1qFFUGhvVX7KwjYsfYAH+FVs/UaAHFf77a\ni0uC47TmZFCPrilBBq4FewlXtF/IHZ6RQ7XbG/RjaQVPDF6tHmlKj06yu2QKfsbs\n+VT2qzMrsVyuESzYUeOheT4izPgsgEywqduFFynXuDn76smo1vGmTIOf70FOYvvF\nZJ89a2nQhv1BKl203aYQMPuUuqXFtchAZjEWkoJCMQKBgQDKH/4l4NKlajq/vjwp\nD8BpEEEEQhwG586F5cgNug4Dh6D+4IJSSygE4S6PEKNtqJCIw6xJaPWWJqvZKufF\nydhuAn/hWfpnf5G1mg3LXg9HXUxbPcF5ykCW5XGWYJrx/WBuSGUWlU7gaXWXVZa3\n0hF1ocol2tX0ipd6V3FNzuo2EQKBgQC7GIyQT8A4EVW+CfkZ0O2WAdWhjvRUvcES\nuMgNCI1mMriURRZB12ziSq5BAC7oB7b6D6qZhJJHUtqTJtq7bhsS0flTfuXMl6gc\naUb1fVjBaeBSfMKdZYnqGYd36VjZvSTnLPUgl66KZdDPFv5TgM+8WWwT/dL+UE9l\n6Pm4hzjM5QKBgQDA2EVjXl2b9P6YcqhzhNPPafKeXXTgIcqpddKpRhqYw46Xnxy3\n530HKtGBLh6/QVSlKAv4/mtSFxNe39DCpRIZ48ie+XovxUcAPTtsDRIGxL1VUFaI\nHLADSGZXU1SCDX0zu163bT0UX4oSGVbzizmdQf/cni4EYzajQ0qXMhPEAQKBgG5T\nAogSTuGA71N5ZAciGQcsm8GBn3fc0N3uUiDFW0PZQthDiOVYV590tB4mMoKmEfKQ\njGOsNemS5MqCzdZaDeLiKChhGray8vGV7r7RpCWg/iMF6GiRuGpvlV9THQ6AJyOe\ncgk/CDAZ67BB+cRZn6WMAVwkf2dxCfCpGaADNK41AoGBAL+dGa9fqOfsKV4fxaQ4\ni1oXS2/5/x4GtR50U2pW5PoSyStb625p+emiPNxXGNX+lsgQ70RS5WW99YX/xUrb\nZnJZPH9r4ylcl1BhtMv3/5glFaZgXRWR0egu/m/nloYhUHCiR3M6Ki+8IcYworDX\npDsO74DpNpWgdxgJQZUKQb3/\n-----END PRIVATE KEY-----\n",
  "client_email": "taxiapp@taxiapp-200711.iam.gserviceaccount.com",
  "client_id": "116018972731339785368",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://accounts.google.com/o/oauth2/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/taxiapp%40taxiapp-200711.iam.gserviceaccount.com"
};

////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"clients.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/clients.js                                                                             //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.export({
  Clients: () => Clients
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
const Clients = new Mongo.Collection('clients');

if (Meteor.isServer) {
  Meteor.publish('Clients', function () {
    console.log(this.userId);

    if (!!this.userId) {
      console.log('test');
      return Clients.find();
    }
  }); // 	var clientList = ["90/24 Sports"
  // ,"Amsterdam Redefined"
  // ,"Atricure"
  // ,"Avega"
  // ,"De Baker Kraamzorg"
  // ,"BAM"
  // ,"Blackrock"
  // ,"Blastradius"
  // ,"Boston Scientific"
  // ,"Brinkmansbeheer"
  // ,"Bunzl"
  // ,"Edelman"
  // ,"Cisi Care"
  // ,"Edison"
  // ,"Equinix"
  // ,"Equinix Nederland"
  // ,"H.I.G."
  // ,"Hoshizaki"
  // ,"Iamsterdam"
  // ,"Johnson&Johnson"
  // ,"Kraam en Co"
  // ,"Mammae Mia"
  // ,"Mirabeau"
  // ,"MSREF"
  // ,"Mylan"
  // ,"Novagraaf"
  // ,"Orange Connect"
  // ,"Pepperminds"
  // ,"Randstad Holding"
  // ,"Mw. A. Schwartz"
  // ,"Service Now"
  // ,"SMS Oncology"
  // ,"South Stream"
  // ,"Stryker"
  // ,"Stryker Flexim"
  // ,"UBS"
  // ,"Uniqure"
  // ,"Zin Kraamzorg"]
  // 	for (var i = clientList.length - 1; i >= 0; i--) {
  // 		Clients.insert({bedrijf: clientList[i]})
  // 	};
}

;
Meteor.methods({
  'Clients.delete'(ID) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      for (var i = ID.length - 1; i >= 0; i--) {
        console.log('removed id: ' + ID[i]);
        Clients.remove({
          _id: ID[i]
        });
      }

      ;
    }
  },

  'Clients.update'(rideId, row) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      Clients.update(rideId, row);
    }
  },

  'Clients.insert'(newRide) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      Clients.insert(newRide);
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rides.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/rides.js                                                                               //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.export({
  RidesDB: () => RidesDB
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let CalendarAPI;
module.watch(require("node-google-calendar"), {
  default(v) {
    CalendarAPI = v;
  }

}, 2);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 3);
module.watch(require("moment/locale/nl"));

const CONFIG = require('./google/Settings');

var total = {};
let cal = new CalendarAPI(CONFIG);
const RidesDB = new Mongo.Collection('rides');

if (Meteor.isServer) {
  Meteor.publish('RidesDB', function () {
    if (!!this.userId) {
      return RidesDB.find();
    }
  });
}

;

function translateIt(params) {
  if (params.includes('pick up:' | 'pickup:' | 'pick-up:' | 'from:')) {
    console.log(params);
  }

  params = params.replace(/ :/g, ':'); // //van

  params = params.replace(/pick up:|pickup:|pick-up:|from:/gi, 'van:'); //naar

  params = params.replace(/to:|drop-off:|drop off:|dropoff:/gi, 'naar:'); //bedrijf

  params = params.replace(/company:|client:/gi, 'bedrijf:'); // passagier

  params = params.replace(/passenger:|naam:|name:/gi, 'passagier:'); //kostenplaats

  params = params.replace(/cost center:|costcenter:/gi, 'kostenplaats:');
  console.log(params);
  return params;
}

function isInteger(x) {
  return x % 1 === 0;
}

function addTotal(params) {
  if (params != undefined && params.charAt(0) === ',') {
    while (params.charAt(0) === ',' || isInteger(params.charAt(0))) {
      params = params.substr(1);
    }

    lowerCase = params.toLowerCase();
    translated = translateIt(lowerCase);

    if (translated.includes('passagier:') || translated.includes('van:') || translated.includes('naar:') || translated.includes('bedrijf:') || translated.includes('comments:' || translated.includes('kostenplaats:'))) {
      var toAdd = jsonIt(translated);
      console.log(toAdd);
    } else {
      var toAdd = [{}];
    }
  } else {
    var toAdd = [{}];
  }

  total = Object.assign(total, toAdd[0]);
  console.log(total);
}

function jsonIt(params) {
  if (params != undefined && params.includes(",") && params.includes(":")) {
    params.replace(/(\r\n|\n|\r)/gm, "");
    var jsonStrig = '[{';
    var items = params.split(',');

    for (var i = 0; i < items.length; i++) {
      var current = items[i].split(':');
      var first = current[0].trim();
      jsonStrig += '"' + first + '":"' + current[1] + '",';
    }

    jsonStrig = jsonStrig.substr(0, jsonStrig.length - 1);
    jsonStrig += '}]';
    var obj = JSON.parse(jsonStrig);
    return obj;
  } else {
    return undefined;
  }
}

;
Meteor.methods({
  'RidesDB.delete'(ID) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      for (var i = ID.length - 1; i >= 0; i--) {
        console.log('removed id: ' + ID[i]);
        RidesDB.remove({
          _id: ID[i]
        });
      }

      ;
    }
  },

  'RidesDB.update'(rideId, row) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      RidesDB.update(rideId, row);
    }
  },

  'RidesDB.insert'(newRide) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      RidesDB.insert(newRide);
    }
  },

  googleSync() {
    if (Meteor.isServer) {
      let currentTime = moment().format('YYYY-MM-DDTHH:mm:ssZ');
      let params = {
        timeMin: moment('May 16, 2018').format('YYYY-MM-DDTHH:mm:ssZ'),
        maxResults: 2500 // timeMax: '2017-05-25T22:00:00+08:00',
        // q: 'query term',
        // singleEvents: true,
        // orderBy: 'startTime'

      }; //Optional query parameters referencing google APIs

      let calendarId = 'info.thijm.ecs@gmail.com';
      getCal = Meteor.bindEnvironment(function (json) {}, function (e) {
        throw e;
      });
      cal.Events.list(calendarId, params).then(Meteor.bindEnvironment(function (json) {
        for (var i = json.length - 1; i >= 0; i--) {
          moment.locale('nl');
          var dateFull = json[i].start.dateTime;
          var date = new Date(json[i].start.dateTime);
          var datum = moment(json[i].start.dateTime).format("YYYY-MM-DD");
          var time = moment(json[i].start.dateTime).format('HH:mm');
          addTotal(json[i].location);
          addTotal(json[i].summary);
          addTotal(json[i].description);

          if (total.kostenplaats === undefined) {
            total.kostenplaats = 'op rekening';
          }

          if (!!!RidesDB.find({
            calId: json[i].id
          }).count()) {
            RidesDB.insert({
              calId: json[i].id,
              dateFull: dateFull,
              date: date,
              datum: datum,
              time: time,
              bedrijf: total.bedrijf,
              passagier: total.passagier,
              locatie: json[i].location,
              van: total.van,
              naar: total.naar,
              titel: json[i].summary,
              beschrijving: json[i].description,
              tel: total.tel,
              kostenplaats: total.kostenplaats,
              comments: total.comments
            });
          } else {
            let cal = RidesDB.findOne({
              calId: json[i].id
            });
            let _id = cal._id; // let bestuurder = cal.bestuurder;
            // let titel = json[i].summary;
            // let beschrijving = json[i].description;
            // let locatie = json[i].location;
            // let van = cal.van;
            // let naar = cal.naar;
            // let tel = cal.tel
            // let bedrijf = cal.bedrijf;
            // let kosten = cal.kosten;
            // let kostenplaats = cal.kostenplaats;
            // let roadshow = cal.roadshow
            // let wachttijd = cal.wachttijd
            // let comments = cal.comments
            // let passagier = cal.passagier
            // let agendapunt = {van: van,passagier: passagier, comments: comments, tel: tel, beschrijving: beschrijving, titel: titel, naar: naar, calId: json[i].id,dateFull: dateFull, date: date,time: time, bestuurder: bestuurder, locatie: locatie,bedrijf: bedrijf,kosten: kosten, kostenplaats: kostenplaats,roadshow: roadshow,wachttijd: wachttijd}
            // // console.log('json: ')
            // // console.log(json[i].summary)
            // // console.log('agendapunt: ')
            // // console.log(agendapunt)
            // RidesDB.update(_id,agendapunt)
            // RidesDB.update(_id,{
            // 		calId : json[i].id,
            // 		dateFull: dateFull,
            // 		date: date,
            // 		time: time,
            // 		datum: datum,
            // 		bedrijf: total.bedrijf,
            // 		passagier: total.passagier,
            // 		locatie: json[i].location,
            // 		van: total.van,
            // 		naar: total.naar,
            // 		titel: json[i].summary,
            // 		beschrijving: json[i].description,
            // 		tel: total.tel,
            // 		kostenplaats: total.kostenplaats,
            // 		comments: total.comments,
            // 		wachttijd: cal.wachttijd,
            // 		roadshow: cal.roadshow,
            // 		kosten: cal.kosten,
            // 		bestuurder: cal.bestuurder
            // 	})
          }

          total = {};
        }

        ;
        return json;
      }, function (e) {
        throw e;
      }));
    }
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/main.js                                                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 3);
let RidesDB;
module.watch(require("./../imports/api/rides"), {
  RidesDB(v) {
    RidesDB = v;
  }

}, 4);
let Clients;
module.watch(require("./../imports/api/clients"), {
  Clients(v) {
    Clients = v;
  }

}, 5);
Meteor.startup(() => {
  RidesDB.remove({}); // code to run on server at startup

  Accounts.validateNewUser(user => {
    const email = user.emails[0].address;

    try {
      new SimpleSchema({
        email: {
          type: String,
          regEx: SimpleSchema.RegEx.Email
        }
      }).validate({
        email
      });
    } catch (e) {
      throw new Meteor.Error(400, e.message);
    }

    return true;
  });
  Accounts.onCreateUser((options, user) => {
    user.profile = {
      role: options.profile.role
    };
    return user;
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ29vZ2xlL1NldHRpbmdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jbGllbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yaWRlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsia2V5IiwicmVxdWlyZSIsInByaXZhdGVfa2V5IiwiU0VSVklDRV9BQ0NUX0lEIiwiQ0FMRU5EQVJfVVJMIiwiQ0FMRU5EQVJfSUQiLCJUSU1FWk9ORSIsIm1vZHVsZSIsImV4cG9ydHMiLCJjYWxlbmRhclVybCIsInNlcnZpY2VBY2N0SWQiLCJjYWxlbmRhcklkIiwidGltZXpvbmUiLCJleHBvcnQiLCJDbGllbnRzIiwiTW9uZ28iLCJ3YXRjaCIsInYiLCJNZXRlb3IiLCJDb2xsZWN0aW9uIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwiY29uc29sZSIsImxvZyIsInVzZXJJZCIsImZpbmQiLCJtZXRob2RzIiwiSUQiLCJlcnJvciIsImkiLCJsZW5ndGgiLCJyZW1vdmUiLCJfaWQiLCJyaWRlSWQiLCJyb3ciLCJ1cGRhdGUiLCJuZXdSaWRlIiwiaW5zZXJ0IiwiUmlkZXNEQiIsIkNhbGVuZGFyQVBJIiwiZGVmYXVsdCIsIm1vbWVudCIsIkNPTkZJRyIsInRvdGFsIiwiY2FsIiwidHJhbnNsYXRlSXQiLCJwYXJhbXMiLCJpbmNsdWRlcyIsInJlcGxhY2UiLCJpc0ludGVnZXIiLCJ4IiwiYWRkVG90YWwiLCJ1bmRlZmluZWQiLCJjaGFyQXQiLCJzdWJzdHIiLCJsb3dlckNhc2UiLCJ0b0xvd2VyQ2FzZSIsInRyYW5zbGF0ZWQiLCJ0b0FkZCIsImpzb25JdCIsIk9iamVjdCIsImFzc2lnbiIsImpzb25TdHJpZyIsIml0ZW1zIiwic3BsaXQiLCJjdXJyZW50IiwiZmlyc3QiLCJ0cmltIiwib2JqIiwiSlNPTiIsInBhcnNlIiwiZ29vZ2xlU3luYyIsImN1cnJlbnRUaW1lIiwiZm9ybWF0IiwidGltZU1pbiIsIm1heFJlc3VsdHMiLCJnZXRDYWwiLCJiaW5kRW52aXJvbm1lbnQiLCJqc29uIiwiZSIsIkV2ZW50cyIsImxpc3QiLCJ0aGVuIiwibG9jYWxlIiwiZGF0ZUZ1bGwiLCJzdGFydCIsImRhdGVUaW1lIiwiZGF0ZSIsIkRhdGUiLCJkYXR1bSIsInRpbWUiLCJsb2NhdGlvbiIsInN1bW1hcnkiLCJkZXNjcmlwdGlvbiIsImtvc3RlbnBsYWF0cyIsImNhbElkIiwiaWQiLCJjb3VudCIsImJlZHJpamYiLCJwYXNzYWdpZXIiLCJsb2NhdGllIiwidmFuIiwibmFhciIsInRpdGVsIiwiYmVzY2hyaWp2aW5nIiwidGVsIiwiY29tbWVudHMiLCJmaW5kT25lIiwiQWNjb3VudHMiLCJTaW1wbGVTY2hlbWEiLCJSb2xlcyIsInN0YXJ0dXAiLCJ2YWxpZGF0ZU5ld1VzZXIiLCJ1c2VyIiwiZW1haWwiLCJlbWFpbHMiLCJhZGRyZXNzIiwidHlwZSIsIlN0cmluZyIsInJlZ0V4IiwiUmVnRXgiLCJFbWFpbCIsInZhbGlkYXRlIiwiRXJyb3IiLCJtZXNzYWdlIiwib25DcmVhdGVVc2VyIiwib3B0aW9ucyIsInByb2ZpbGUiLCJyb2xlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLE1BQU1BLE1BQU1DLFFBQVEsNkJBQVIsRUFBdUNDLFdBQW5EOztBQUdBLE1BQU1DLGtCQUFrQixnREFBeEI7QUFDQSxNQUFNQyxlQUFlLCtFQUFyQjtBQUNBLE1BQU1DLGNBQWM7QUFDbkIsYUFBVztBQURRLENBQXBCO0FBR0EsTUFBTUMsV0FBVyxXQUFqQjtBQUVBQyxPQUFPQyxPQUFQLENBQWVDLFdBQWYsR0FBNkJMLFlBQTdCO0FBQ0FHLE9BQU9DLE9BQVAsQ0FBZUUsYUFBZixHQUErQlAsZUFBL0I7QUFDQUksT0FBT0MsT0FBUCxDQUFlRyxVQUFmLEdBQTRCTixXQUE1QjtBQUNBRSxPQUFPQyxPQUFQLENBQWVSLEdBQWYsR0FBcUJBLEdBQXJCO0FBQ0FPLE9BQU9DLE9BQVAsQ0FBZUksUUFBZixHQUEwQk4sUUFBMUIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RBQyxPQUFPTSxNQUFQLENBQWM7QUFBQ0MsV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSUMsS0FBSjtBQUFVUixPQUFPUyxLQUFQLENBQWFmLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNjLFFBQU1FLENBQU4sRUFBUTtBQUFDRixZQUFNRSxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlDLE1BQUo7QUFBV1gsT0FBT1MsS0FBUCxDQUFhZixRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDaUIsU0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHL0csTUFBTUgsVUFBVSxJQUFJQyxNQUFNSSxVQUFWLENBQXFCLFNBQXJCLENBQWhCOztBQUdQLElBQUlELE9BQU9FLFFBQVgsRUFBcUI7QUFDcEJGLFNBQU9HLE9BQVAsQ0FBZSxTQUFmLEVBQTBCLFlBQVc7QUFDcENDLFlBQVFDLEdBQVIsQ0FBWSxLQUFLQyxNQUFqQjs7QUFDQSxRQUFJLENBQUMsQ0FBQyxLQUFLQSxNQUFYLEVBQW1CO0FBQ2xCRixjQUFRQyxHQUFSLENBQVksTUFBWjtBQUNBLGFBQU9ULFFBQVFXLElBQVIsRUFBUDtBQUNBO0FBQ0QsR0FORCxFQURvQixDQVFyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0M7O0FBQUE7QUFFRFAsT0FBT1EsT0FBUCxDQUFlO0FBQ1osbUJBQWtCQyxFQUFsQixFQUFzQjtBQUNyQixRQUFJLENBQUMsS0FBS0gsTUFBVixFQUFrQjtBQUNqQixZQUFNLElBQUlOLE9BQU9VLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQSxLQUZELE1BRU87QUFDTixXQUFLLElBQUlDLElBQUlGLEdBQUdHLE1BQUgsR0FBWSxDQUF6QixFQUE0QkQsS0FBSyxDQUFqQyxFQUFvQ0EsR0FBcEMsRUFBeUM7QUFDeENQLGdCQUFRQyxHQUFSLENBQVksaUJBQWdCSSxHQUFHRSxDQUFILENBQTVCO0FBQ0FmLGdCQUFRaUIsTUFBUixDQUFlO0FBQUNDLGVBQUtMLEdBQUdFLENBQUg7QUFBTixTQUFmO0FBQ0E7O0FBQUE7QUFDRDtBQUVELEdBWFc7O0FBV1YsbUJBQWtCSSxNQUFsQixFQUF5QkMsR0FBekIsRUFBOEI7QUFDL0IsUUFBSSxDQUFDLEtBQUtWLE1BQVYsRUFBa0I7QUFDakIsWUFBTSxJQUFJTixPQUFPVSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ05kLGNBQVFxQixNQUFSLENBQWVGLE1BQWYsRUFBc0JDLEdBQXRCO0FBQ0E7QUFFRCxHQWxCVzs7QUFrQlYsbUJBQWtCRSxPQUFsQixFQUEyQjtBQUM1QixRQUFJLENBQUMsS0FBS1osTUFBVixFQUFrQjtBQUNqQixZQUFNLElBQUlOLE9BQU9VLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDQSxLQUZELE1BRU87QUFDTmQsY0FBUXVCLE1BQVIsQ0FBZUQsT0FBZjtBQUNBO0FBRUQ7O0FBekJXLENBQWYsRTs7Ozs7Ozs7Ozs7QUMxREE3QixPQUFPTSxNQUFQLENBQWM7QUFBQ3lCLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUl2QixLQUFKO0FBQVVSLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2MsUUFBTUUsQ0FBTixFQUFRO0FBQUNGLFlBQU1FLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSUMsTUFBSjtBQUFXWCxPQUFPUyxLQUFQLENBQWFmLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNpQixTQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJc0IsV0FBSjtBQUFnQmhDLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUN1QyxVQUFRdkIsQ0FBUixFQUFVO0FBQUNzQixrQkFBWXRCLENBQVo7QUFBYzs7QUFBMUIsQ0FBN0MsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSXdCLE1BQUo7QUFBV2xDLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ3VDLFVBQVF2QixDQUFSLEVBQVU7QUFBQ3dCLGFBQU94QixDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlEVixPQUFPUyxLQUFQLENBQWFmLFFBQVEsa0JBQVIsQ0FBYjs7QUFLclYsTUFBTXlDLFNBQVN6QyxRQUFRLG1CQUFSLENBQWY7O0FBQ0EsSUFBSTBDLFFBQVEsRUFBWjtBQUVBLElBQUlDLE1BQU0sSUFBSUwsV0FBSixDQUFnQkcsTUFBaEIsQ0FBVjtBQUdPLE1BQU1KLFVBQVUsSUFBSXZCLE1BQU1JLFVBQVYsQ0FBcUIsT0FBckIsQ0FBaEI7O0FBRVAsSUFBSUQsT0FBT0UsUUFBWCxFQUFxQjtBQUNwQkYsU0FBT0csT0FBUCxDQUFlLFNBQWYsRUFBMEIsWUFBVztBQUNwQyxRQUFJLENBQUMsQ0FBQyxLQUFLRyxNQUFYLEVBQW1CO0FBQ2xCLGFBQU9jLFFBQVFiLElBQVIsRUFBUDtBQUNBO0FBQ0QsR0FKRDtBQUtBOztBQUFBOztBQUdELFNBQVNvQixXQUFULENBQXFCQyxNQUFyQixFQUE2QjtBQUM1QixNQUFHQSxPQUFPQyxRQUFQLENBQWdCLGFBQVcsU0FBWCxHQUFxQixVQUFyQixHQUFnQyxPQUFoRCxDQUFILEVBQTZEO0FBQzNEekIsWUFBUUMsR0FBUixDQUFZdUIsTUFBWjtBQUNEOztBQUNEQSxXQUFTQSxPQUFPRSxPQUFQLENBQWUsS0FBZixFQUFxQixHQUFyQixDQUFULENBSjRCLENBTTVCOztBQUNBRixXQUFTQSxPQUFPRSxPQUFQLENBQWUsbUNBQWYsRUFBbUQsTUFBbkQsQ0FBVCxDQVA0QixDQVE1Qjs7QUFDQUYsV0FBU0EsT0FBT0UsT0FBUCxDQUFlLG9DQUFmLEVBQW9ELE9BQXBELENBQVQsQ0FUNEIsQ0FVNUI7O0FBQ0FGLFdBQVNBLE9BQU9FLE9BQVAsQ0FBZSxvQkFBZixFQUFvQyxVQUFwQyxDQUFULENBWDRCLENBWTVCOztBQUNBRixXQUFTQSxPQUFPRSxPQUFQLENBQWUsMEJBQWYsRUFBMEMsWUFBMUMsQ0FBVCxDQWI0QixDQWM1Qjs7QUFDQUYsV0FBU0EsT0FBT0UsT0FBUCxDQUFlLDRCQUFmLEVBQTRDLGVBQTVDLENBQVQ7QUFFQTFCLFVBQVFDLEdBQVIsQ0FBWXVCLE1BQVo7QUFHQSxTQUFPQSxNQUFQO0FBQ0E7O0FBRUQsU0FBU0csU0FBVCxDQUFtQkMsQ0FBbkIsRUFBc0I7QUFDbEIsU0FBT0EsSUFBSSxDQUFKLEtBQVUsQ0FBakI7QUFDSDs7QUFFRCxTQUFTQyxRQUFULENBQWtCTCxNQUFsQixFQUEwQjtBQUN6QixNQUFHQSxVQUFVTSxTQUFWLElBQXVCTixPQUFPTyxNQUFQLENBQWMsQ0FBZCxNQUFxQixHQUEvQyxFQUFvRDtBQUNuRCxXQUFNUCxPQUFPTyxNQUFQLENBQWMsQ0FBZCxNQUFxQixHQUFyQixJQUE0QkosVUFBVUgsT0FBT08sTUFBUCxDQUFjLENBQWQsQ0FBVixDQUFsQyxFQUE4RDtBQUM1RFAsZUFBU0EsT0FBT1EsTUFBUCxDQUFjLENBQWQsQ0FBVDtBQUNBOztBQUNGQyxnQkFBWVQsT0FBT1UsV0FBUCxFQUFaO0FBQ0FDLGlCQUFhWixZQUFZVSxTQUFaLENBQWI7O0FBRUEsUUFBR0UsV0FBV1YsUUFBWCxDQUFvQixZQUFwQixLQUFxQ1UsV0FBV1YsUUFBWCxDQUFvQixNQUFwQixDQUFyQyxJQUFvRVUsV0FBV1YsUUFBWCxDQUFvQixPQUFwQixDQUFwRSxJQUFvR1UsV0FBV1YsUUFBWCxDQUFvQixVQUFwQixDQUFwRyxJQUF1SVUsV0FBV1YsUUFBWCxDQUFvQixlQUFlVSxXQUFXVixRQUFYLENBQW9CLGVBQXBCLENBQW5DLENBQTFJLEVBQW1OO0FBQ2xOLFVBQUlXLFFBQVFDLE9BQU9GLFVBQVAsQ0FBWjtBQUNBbkMsY0FBUUMsR0FBUixDQUFZbUMsS0FBWjtBQUNBLEtBSEQsTUFHTztBQUNQLFVBQUlBLFFBQVEsQ0FBQyxFQUFELENBQVo7QUFDQztBQUNELEdBYkQsTUFhTztBQUNOLFFBQUlBLFFBQVEsQ0FBQyxFQUFELENBQVo7QUFDRDs7QUFDQWYsVUFBUWlCLE9BQU9DLE1BQVAsQ0FBY2xCLEtBQWQsRUFBb0JlLE1BQU0sQ0FBTixDQUFwQixDQUFSO0FBQ0FwQyxVQUFRQyxHQUFSLENBQVlvQixLQUFaO0FBQ0E7O0FBRUQsU0FBU2dCLE1BQVQsQ0FBZ0JiLE1BQWhCLEVBQXdCO0FBQ3ZCLE1BQUlBLFVBQVVNLFNBQVYsSUFBdUJOLE9BQU9DLFFBQVAsQ0FBZ0IsR0FBaEIsQ0FBdkIsSUFBK0NELE9BQU9DLFFBQVAsQ0FBZ0IsR0FBaEIsQ0FBbkQsRUFBMEU7QUFDekVELFdBQU9FLE9BQVAsQ0FBZSxnQkFBZixFQUFnQyxFQUFoQztBQUNBLFFBQUljLFlBQVksSUFBaEI7QUFDQSxRQUFJQyxRQUFRakIsT0FBT2tCLEtBQVAsQ0FBYSxHQUFiLENBQVo7O0FBQ0EsU0FBSyxJQUFJbkMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJa0MsTUFBTWpDLE1BQTFCLEVBQWtDRCxHQUFsQyxFQUF1QztBQUNyQyxVQUFJb0MsVUFBVUYsTUFBTWxDLENBQU4sRUFBU21DLEtBQVQsQ0FBZSxHQUFmLENBQWQ7QUFDQSxVQUFJRSxRQUFRRCxRQUFRLENBQVIsRUFBV0UsSUFBWCxFQUFaO0FBQ0FMLG1CQUFhLE1BQU1JLEtBQU4sR0FBYyxLQUFkLEdBQXNCRCxRQUFRLENBQVIsQ0FBdEIsR0FBbUMsSUFBaEQ7QUFDRDs7QUFDREgsZ0JBQVlBLFVBQVVSLE1BQVYsQ0FBaUIsQ0FBakIsRUFBb0JRLFVBQVVoQyxNQUFWLEdBQW1CLENBQXZDLENBQVo7QUFDQWdDLGlCQUFhLElBQWI7QUFDQSxRQUFJTSxNQUFNQyxLQUFLQyxLQUFMLENBQVdSLFNBQVgsQ0FBVjtBQUNBLFdBQU9NLEdBQVA7QUFDRSxHQWJILE1BYVM7QUFDTixXQUFPaEIsU0FBUDtBQUNEO0FBQ0Y7O0FBQUE7QUFHRGxDLE9BQU9RLE9BQVAsQ0FBZTtBQUNaLG1CQUFrQkMsRUFBbEIsRUFBc0I7QUFDckIsUUFBSSxDQUFDLEtBQUtILE1BQVYsRUFBa0I7QUFDakIsWUFBTSxJQUFJTixPQUFPVSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ04sV0FBSyxJQUFJQyxJQUFJRixHQUFHRyxNQUFILEdBQVksQ0FBekIsRUFBNEJELEtBQUssQ0FBakMsRUFBb0NBLEdBQXBDLEVBQXlDO0FBQ3hDUCxnQkFBUUMsR0FBUixDQUFZLGlCQUFnQkksR0FBR0UsQ0FBSCxDQUE1QjtBQUNBUyxnQkFBUVAsTUFBUixDQUFlO0FBQUNDLGVBQUtMLEdBQUdFLENBQUg7QUFBTixTQUFmO0FBQ0E7O0FBQUE7QUFDRDtBQUVELEdBWFc7O0FBV1YsbUJBQWtCSSxNQUFsQixFQUF5QkMsR0FBekIsRUFBOEI7QUFDL0IsUUFBSSxDQUFDLEtBQUtWLE1BQVYsRUFBa0I7QUFDakIsWUFBTSxJQUFJTixPQUFPVSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ05VLGNBQVFILE1BQVIsQ0FBZUYsTUFBZixFQUFzQkMsR0FBdEI7QUFDQTtBQUVELEdBbEJXOztBQWtCVixtQkFBa0JFLE9BQWxCLEVBQTJCO0FBQzVCLFFBQUksQ0FBQyxLQUFLWixNQUFWLEVBQWtCO0FBQ2pCLFlBQU0sSUFBSU4sT0FBT1UsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBLEtBRkQsTUFFTztBQUNOVSxjQUFRRCxNQUFSLENBQWVELE9BQWY7QUFDQTtBQUVELEdBekJXOztBQTBCWm1DLGVBQWE7QUFDWixRQUFJckQsT0FBT0UsUUFBWCxFQUFxQjtBQUNwQixVQUFJb0QsY0FBYy9CLFNBQVNnQyxNQUFULENBQWdCLHNCQUFoQixDQUFsQjtBQUNBLFVBQUkzQixTQUFTO0FBQ1o0QixpQkFBU2pDLE9BQU8sY0FBUCxFQUF1QmdDLE1BQXZCLENBQThCLHNCQUE5QixDQURHO0FBRVpFLG9CQUFZLElBRkEsQ0FHWjtBQUNBO0FBQ0E7QUFDQTs7QUFOWSxPQUFiLENBRm9CLENBU2pCOztBQUNILFVBQUloRSxhQUFhLDBCQUFqQjtBQUVBaUUsZUFBUzFELE9BQU8yRCxlQUFQLENBQXVCLFVBQVNDLElBQVQsRUFBZSxDQUU5QyxDQUZRLEVBRU4sVUFBU0MsQ0FBVCxFQUFZO0FBQ2QsY0FBTUEsQ0FBTjtBQUNBLE9BSlEsQ0FBVDtBQU1BbkMsVUFBSW9DLE1BQUosQ0FBV0MsSUFBWCxDQUFnQnRFLFVBQWhCLEVBQTRCbUMsTUFBNUIsRUFDRW9DLElBREYsQ0FDT2hFLE9BQU8yRCxlQUFQLENBQXVCLFVBQVNDLElBQVQsRUFBZTtBQUMxQyxhQUFLLElBQUlqRCxJQUFJaUQsS0FBS2hELE1BQUwsR0FBYyxDQUEzQixFQUE4QkQsS0FBSyxDQUFuQyxFQUFzQ0EsR0FBdEMsRUFBMkM7QUFDMUNZLGlCQUFPMEMsTUFBUCxDQUFjLElBQWQ7QUFDQSxjQUFJQyxXQUFXTixLQUFLakQsQ0FBTCxFQUFRd0QsS0FBUixDQUFjQyxRQUE3QjtBQUNBLGNBQUlDLE9BQU8sSUFBSUMsSUFBSixDQUFTVixLQUFLakQsQ0FBTCxFQUFRd0QsS0FBUixDQUFjQyxRQUF2QixDQUFYO0FBQ0EsY0FBSUcsUUFBUWhELE9BQU9xQyxLQUFLakQsQ0FBTCxFQUFRd0QsS0FBUixDQUFjQyxRQUFyQixFQUErQmIsTUFBL0IsQ0FBc0MsWUFBdEMsQ0FBWjtBQUNBLGNBQUlpQixPQUFPakQsT0FBT3FDLEtBQUtqRCxDQUFMLEVBQVF3RCxLQUFSLENBQWNDLFFBQXJCLEVBQStCYixNQUEvQixDQUFzQyxPQUF0QyxDQUFYO0FBRUF0QixtQkFBUzJCLEtBQUtqRCxDQUFMLEVBQVE4RCxRQUFqQjtBQUNBeEMsbUJBQVMyQixLQUFLakQsQ0FBTCxFQUFRK0QsT0FBakI7QUFDQXpDLG1CQUFTMkIsS0FBS2pELENBQUwsRUFBUWdFLFdBQWpCOztBQUVBLGNBQUdsRCxNQUFNbUQsWUFBTixLQUF1QjFDLFNBQTFCLEVBQXFDO0FBQ3BDVCxrQkFBTW1ELFlBQU4sR0FBcUIsYUFBckI7QUFDQTs7QUFFRCxjQUFHLENBQUMsQ0FBQyxDQUFDeEQsUUFBUWIsSUFBUixDQUFhO0FBQUNzRSxtQkFBT2pCLEtBQUtqRCxDQUFMLEVBQVFtRTtBQUFoQixXQUFiLEVBQWtDQyxLQUFsQyxFQUFOLEVBQWlEO0FBQ2hEM0Qsb0JBQVFELE1BQVIsQ0FBZTtBQUNkMEQscUJBQVFqQixLQUFLakQsQ0FBTCxFQUFRbUUsRUFERjtBQUVkWix3QkFBVUEsUUFGSTtBQUdkRyxvQkFBTUEsSUFIUTtBQUlkRSxxQkFBT0EsS0FKTztBQUtkQyxvQkFBTUEsSUFMUTtBQU1kUSx1QkFBU3ZELE1BQU11RCxPQU5EO0FBT2RDLHlCQUFXeEQsTUFBTXdELFNBUEg7QUFRZEMsdUJBQVN0QixLQUFLakQsQ0FBTCxFQUFROEQsUUFSSDtBQVNkVSxtQkFBSzFELE1BQU0wRCxHQVRHO0FBVWRDLG9CQUFNM0QsTUFBTTJELElBVkU7QUFXZEMscUJBQU96QixLQUFLakQsQ0FBTCxFQUFRK0QsT0FYRDtBQVlkWSw0QkFBYzFCLEtBQUtqRCxDQUFMLEVBQVFnRSxXQVpSO0FBYWRZLG1CQUFLOUQsTUFBTThELEdBYkc7QUFjZFgsNEJBQWNuRCxNQUFNbUQsWUFkTjtBQWVkWSx3QkFBVS9ELE1BQU0rRDtBQWZGLGFBQWY7QUFrQkEsV0FuQkQsTUFtQk87QUFDTixnQkFBSTlELE1BQU1OLFFBQVFxRSxPQUFSLENBQWdCO0FBQUNaLHFCQUFPakIsS0FBS2pELENBQUwsRUFBUW1FO0FBQWhCLGFBQWhCLENBQVY7QUFDQSxnQkFBSWhFLE1BQU1ZLElBQUlaLEdBQWQsQ0FGTSxDQUdOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTs7QUFDRFcsa0JBQVEsRUFBUjtBQUNBOztBQUFBO0FBQ0QsZUFBT21DLElBQVA7QUFFQSxPQXRGSSxFQXNGRixVQUFTQyxDQUFULEVBQVk7QUFDZCxjQUFNQSxDQUFOO0FBQ0EsT0F4RkksQ0FEUDtBQTBGRTtBQUNGOztBQXhJVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDMUZBLElBQUk3RCxNQUFKO0FBQVdYLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2lCLFNBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUkyRixRQUFKO0FBQWFyRyxPQUFPUyxLQUFQLENBQWFmLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDMkcsV0FBUzNGLENBQVQsRUFBVztBQUFDMkYsZUFBUzNGLENBQVQ7QUFBVzs7QUFBeEIsQ0FBN0MsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSTRGLFlBQUo7QUFBaUJ0RyxPQUFPUyxLQUFQLENBQWFmLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUN1QyxVQUFRdkIsQ0FBUixFQUFVO0FBQUM0RixtQkFBYTVGLENBQWI7QUFBZTs7QUFBM0IsQ0FBckMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSTZGLEtBQUo7QUFBVXZHLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUM2RyxRQUFNN0YsQ0FBTixFQUFRO0FBQUM2RixZQUFNN0YsQ0FBTjtBQUFROztBQUFsQixDQUE5QyxFQUFrRSxDQUFsRTtBQUFxRSxJQUFJcUIsT0FBSjtBQUFZL0IsT0FBT1MsS0FBUCxDQUFhZixRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ3FDLFVBQVFyQixDQUFSLEVBQVU7QUFBQ3FCLGNBQVFyQixDQUFSO0FBQVU7O0FBQXRCLENBQS9DLEVBQXVFLENBQXZFO0FBQTBFLElBQUlILE9BQUo7QUFBWVAsT0FBT1MsS0FBUCxDQUFhZixRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ2EsVUFBUUcsQ0FBUixFQUFVO0FBQUNILGNBQVFHLENBQVI7QUFBVTs7QUFBdEIsQ0FBakQsRUFBeUUsQ0FBekU7QUFReGFDLE9BQU82RixPQUFQLENBQWUsTUFBTTtBQUNuQnpFLFVBQVFQLE1BQVIsQ0FBZSxFQUFmLEVBRG1CLENBRXBCOztBQUNENkUsV0FBU0ksZUFBVCxDQUEwQkMsSUFBRCxJQUFVO0FBQy9CLFVBQU1DLFFBQVFELEtBQUtFLE1BQUwsQ0FBWSxDQUFaLEVBQWVDLE9BQTdCOztBQUVBLFFBQUk7QUFDRixVQUFJUCxZQUFKLENBQWlCO0FBQ2ZLLGVBQU87QUFDTEcsZ0JBQU1DLE1BREQ7QUFFTEMsaUJBQU9WLGFBQWFXLEtBQWIsQ0FBbUJDO0FBRnJCO0FBRFEsT0FBakIsRUFLR0MsUUFMSCxDQUtZO0FBQUVSO0FBQUYsT0FMWjtBQU1ELEtBUEQsQ0FPRSxPQUFPbkMsQ0FBUCxFQUFVO0FBQ1YsWUFBTSxJQUFJN0QsT0FBT3lHLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0I1QyxFQUFFNkMsT0FBeEIsQ0FBTjtBQUNEOztBQUVELFdBQU8sSUFBUDtBQUNELEdBZkg7QUFpQkNoQixXQUFTaUIsWUFBVCxDQUFzQixDQUFDQyxPQUFELEVBQVViLElBQVYsS0FBbUI7QUFDeENBLFNBQUtjLE9BQUwsR0FBZTtBQUFDQyxZQUFNRixRQUFRQyxPQUFSLENBQWdCQztBQUF2QixLQUFmO0FBQ0EsV0FBT2YsSUFBUDtBQUNBLEdBSEQ7QUFNQSxDQTFCRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBrZXkgPSByZXF1aXJlKCcuL3RheGlhcHAtNjBkMGViMjUzOTU5Lmpzb24nKS5wcml2YXRlX2tleTtcblxuXG5jb25zdCBTRVJWSUNFX0FDQ1RfSUQgPSAndGF4aWFwcEB0YXhpYXBwLTIwMDcxMS5pYW0uZ3NlcnZpY2VhY2NvdW50LmNvbSc7XG5jb25zdCBDQUxFTkRBUl9VUkwgPSAnaHR0cHM6Ly9jYWxlbmRhci5nb29nbGUuY29tL2NhbGVuZGFyL2IvMj9jaWQ9YVc1bWJ5NTBhR2xxYlM1bFkzTkFaMjFoYVd3dVkyOXQnO1xuY29uc3QgQ0FMRU5EQVJfSUQgPSB7XG5cdCdwcmltYXJ5JzogJ2luZm8udGhpam0uZWNzQGdtYWlsLmNvbSdcbn07XG5jb25zdCBUSU1FWk9ORSA9ICdHTVQrMDI6MDAnO1xuXG5tb2R1bGUuZXhwb3J0cy5jYWxlbmRhclVybCA9IENBTEVOREFSX1VSTDtcbm1vZHVsZS5leHBvcnRzLnNlcnZpY2VBY2N0SWQgPSBTRVJWSUNFX0FDQ1RfSUQ7XG5tb2R1bGUuZXhwb3J0cy5jYWxlbmRhcklkID0gQ0FMRU5EQVJfSUQ7XG5tb2R1bGUuZXhwb3J0cy5rZXkgPSBrZXk7XG5tb2R1bGUuZXhwb3J0cy50aW1lem9uZSA9IFRJTUVaT05FOyIsImltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuXG5leHBvcnQgY29uc3QgQ2xpZW50cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjbGllbnRzJylcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdE1ldGVvci5wdWJsaXNoKCdDbGllbnRzJywgZnVuY3Rpb24oKSB7XG5cdFx0Y29uc29sZS5sb2codGhpcy51c2VySWQpXG5cdFx0aWYgKCEhdGhpcy51c2VySWQpIHtcblx0XHRcdGNvbnNvbGUubG9nKCd0ZXN0Jylcblx0XHRcdHJldHVybiBDbGllbnRzLmZpbmQoKTtcblx0XHR9XG5cdH0pXG4vLyBcdHZhciBjbGllbnRMaXN0ID0gW1wiOTAvMjQgU3BvcnRzXCJcbi8vICxcIkFtc3RlcmRhbSBSZWRlZmluZWRcIlxuLy8gLFwiQXRyaWN1cmVcIlxuLy8gLFwiQXZlZ2FcIlxuLy8gLFwiRGUgQmFrZXIgS3JhYW16b3JnXCJcbi8vICxcIkJBTVwiXG4vLyAsXCJCbGFja3JvY2tcIlxuLy8gLFwiQmxhc3RyYWRpdXNcIlxuLy8gLFwiQm9zdG9uIFNjaWVudGlmaWNcIlxuLy8gLFwiQnJpbmttYW5zYmVoZWVyXCJcbi8vICxcIkJ1bnpsXCJcbi8vICxcIkVkZWxtYW5cIlxuLy8gLFwiQ2lzaSBDYXJlXCJcbi8vICxcIkVkaXNvblwiXG4vLyAsXCJFcXVpbml4XCJcbi8vICxcIkVxdWluaXggTmVkZXJsYW5kXCJcbi8vICxcIkguSS5HLlwiXG4vLyAsXCJIb3NoaXpha2lcIlxuLy8gLFwiSWFtc3RlcmRhbVwiXG4vLyAsXCJKb2huc29uJkpvaG5zb25cIlxuLy8gLFwiS3JhYW0gZW4gQ29cIlxuLy8gLFwiTWFtbWFlIE1pYVwiXG4vLyAsXCJNaXJhYmVhdVwiXG4vLyAsXCJNU1JFRlwiXG4vLyAsXCJNeWxhblwiXG4vLyAsXCJOb3ZhZ3JhYWZcIlxuLy8gLFwiT3JhbmdlIENvbm5lY3RcIlxuLy8gLFwiUGVwcGVybWluZHNcIlxuLy8gLFwiUmFuZHN0YWQgSG9sZGluZ1wiXG4vLyAsXCJNdy4gQS4gU2Nod2FydHpcIlxuLy8gLFwiU2VydmljZSBOb3dcIlxuLy8gLFwiU01TIE9uY29sb2d5XCJcbi8vICxcIlNvdXRoIFN0cmVhbVwiXG4vLyAsXCJTdHJ5a2VyXCJcbi8vICxcIlN0cnlrZXIgRmxleGltXCJcbi8vICxcIlVCU1wiXG4vLyAsXCJVbmlxdXJlXCJcbi8vICxcIlppbiBLcmFhbXpvcmdcIl1cblxuLy8gXHRmb3IgKHZhciBpID0gY2xpZW50TGlzdC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuLy8gXHRcdENsaWVudHMuaW5zZXJ0KHtiZWRyaWpmOiBjbGllbnRMaXN0W2ldfSlcbi8vIFx0fTtcbn07XG5cbk1ldGVvci5tZXRob2RzKHtcblx0XHRcdCdDbGllbnRzLmRlbGV0ZScgKElEKSB7XG5cdFx0XHRcdGlmICghdGhpcy51c2VySWQpIHtcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLmVycm9yKCdub3QgYXV0aGVyaXplZCcpXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Zm9yICh2YXIgaSA9IElELmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZygncmVtb3ZlZCBpZDogJysgSURbaV0pXG5cdFx0XHRcdFx0XHRDbGllbnRzLnJlbW92ZSh7X2lkOiBJRFtpXX0pXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fVxuXG5cdFx0XHR9LCdDbGllbnRzLnVwZGF0ZScgKHJpZGVJZCxyb3cpIHtcblx0XHRcdFx0aWYgKCF0aGlzLnVzZXJJZCkge1xuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuZXJyb3IoJ25vdCBhdXRoZXJpemVkJylcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRDbGllbnRzLnVwZGF0ZShyaWRlSWQscm93KVxuXHRcdFx0XHR9XG5cblx0XHRcdH0sJ0NsaWVudHMuaW5zZXJ0JyAobmV3UmlkZSkge1xuXHRcdFx0XHRpZiAoIXRoaXMudXNlcklkKSB7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5lcnJvcignbm90IGF1dGhlcml6ZWQnKVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdENsaWVudHMuaW5zZXJ0KG5ld1JpZGUpXG5cdFx0XHRcdH1cblxuXHRcdFx0fVxuXHR9KTtcbiIsImltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IENhbGVuZGFyQVBJIGZyb20gJ25vZGUtZ29vZ2xlLWNhbGVuZGFyJ1xuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnXG5pbXBvcnQgJ21vbWVudC9sb2NhbGUvbmwnO1xuY29uc3QgQ09ORklHID0gcmVxdWlyZSgnLi9nb29nbGUvU2V0dGluZ3MnKTtcbnZhciB0b3RhbCA9IHt9XG5cbmxldCBjYWwgPSBuZXcgQ2FsZW5kYXJBUEkoQ09ORklHKTtcblxuXG5leHBvcnQgY29uc3QgUmlkZXNEQiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdyaWRlcycpXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcblx0TWV0ZW9yLnB1Ymxpc2goJ1JpZGVzREInLCBmdW5jdGlvbigpIHtcblx0XHRpZiAoISF0aGlzLnVzZXJJZCkge1xuXHRcdFx0cmV0dXJuIFJpZGVzREIuZmluZCgpO1xuXHRcdH1cblx0fSlcbn07XG5cblxuZnVuY3Rpb24gdHJhbnNsYXRlSXQocGFyYW1zKSB7XG5cdGlmKHBhcmFtcy5pbmNsdWRlcygncGljayB1cDonfCdwaWNrdXA6J3wncGljay11cDonfCdmcm9tOicpKSB7XG5cdFx0XHRjb25zb2xlLmxvZyhwYXJhbXMpXG5cdH1cblx0cGFyYW1zID0gcGFyYW1zLnJlcGxhY2UoLyA6L2csJzonKVxuXHRcblx0Ly8gLy92YW5cblx0cGFyYW1zID0gcGFyYW1zLnJlcGxhY2UoL3BpY2sgdXA6fHBpY2t1cDp8cGljay11cDp8ZnJvbTovZ2ksJ3ZhbjonKVxuXHQvL25hYXJcblx0cGFyYW1zID0gcGFyYW1zLnJlcGxhY2UoL3RvOnxkcm9wLW9mZjp8ZHJvcCBvZmY6fGRyb3BvZmY6L2dpLCduYWFyOicpXG5cdC8vYmVkcmlqZlxuXHRwYXJhbXMgPSBwYXJhbXMucmVwbGFjZSgvY29tcGFueTp8Y2xpZW50Oi9naSwnYmVkcmlqZjonKVxuXHQvLyBwYXNzYWdpZXJcblx0cGFyYW1zID0gcGFyYW1zLnJlcGxhY2UoL3Bhc3Nlbmdlcjp8bmFhbTp8bmFtZTovZ2ksJ3Bhc3NhZ2llcjonKVxuXHQvL2tvc3RlbnBsYWF0c1xuXHRwYXJhbXMgPSBwYXJhbXMucmVwbGFjZSgvY29zdCBjZW50ZXI6fGNvc3RjZW50ZXI6L2dpLCdrb3N0ZW5wbGFhdHM6Jylcblx0XG5cdGNvbnNvbGUubG9nKHBhcmFtcylcblx0XG5cblx0cmV0dXJuIHBhcmFtc1xufVxuXG5mdW5jdGlvbiBpc0ludGVnZXIoeCkge1xuICAgIHJldHVybiB4ICUgMSA9PT0gMDtcbn1cblxuZnVuY3Rpb24gYWRkVG90YWwocGFyYW1zKSB7XG5cdGlmKHBhcmFtcyAhPSB1bmRlZmluZWQgJiYgcGFyYW1zLmNoYXJBdCgwKSA9PT0gJywnKSB7XG5cdFx0d2hpbGUocGFyYW1zLmNoYXJBdCgwKSA9PT0gJywnIHx8IGlzSW50ZWdlcihwYXJhbXMuY2hhckF0KDApKSl7XG5cdFx0XHQgcGFyYW1zID0gcGFyYW1zLnN1YnN0cigxKTtcblx0XHRcdH1cblx0XHRsb3dlckNhc2UgPSBwYXJhbXMudG9Mb3dlckNhc2UoKVxuXHRcdHRyYW5zbGF0ZWQgPSB0cmFuc2xhdGVJdChsb3dlckNhc2UpXG5cblx0XHRpZih0cmFuc2xhdGVkLmluY2x1ZGVzKCdwYXNzYWdpZXI6JykgfHwgdHJhbnNsYXRlZC5pbmNsdWRlcygndmFuOicpIHx8IHRyYW5zbGF0ZWQuaW5jbHVkZXMoJ25hYXI6JykgfHwgdHJhbnNsYXRlZC5pbmNsdWRlcygnYmVkcmlqZjonKSB8fCB0cmFuc2xhdGVkLmluY2x1ZGVzKCdjb21tZW50czonIHx8IHRyYW5zbGF0ZWQuaW5jbHVkZXMoJ2tvc3RlbnBsYWF0czonKSkpe1xuXHRcdFx0dmFyIHRvQWRkID0ganNvbkl0KHRyYW5zbGF0ZWQpXG5cdFx0XHRjb25zb2xlLmxvZyh0b0FkZClcblx0XHR9IGVsc2Uge1xuXHRcdHZhciB0b0FkZCA9IFt7fV1cblx0XHR9XG5cdH0gZWxzZSB7XG5cdFx0dmFyIHRvQWRkID0gW3t9XVxufVxuXHR0b3RhbCA9IE9iamVjdC5hc3NpZ24odG90YWwsdG9BZGRbMF0pXG5cdGNvbnNvbGUubG9nKHRvdGFsKVxufVxuXG5mdW5jdGlvbiBqc29uSXQocGFyYW1zKSB7XG5cdGlmKCBwYXJhbXMgIT0gdW5kZWZpbmVkICYmIHBhcmFtcy5pbmNsdWRlcyhcIixcIikgJiYgcGFyYW1zLmluY2x1ZGVzKFwiOlwiKSApIHtcblx0XHRwYXJhbXMucmVwbGFjZSgvKFxcclxcbnxcXG58XFxyKS9nbSxcIlwiKVxuXHRcdHZhciBqc29uU3RyaWcgPSAnW3snO1xuXHRcdHZhciBpdGVtcyA9IHBhcmFtcy5zcGxpdCgnLCcpO1xuXHRcdGZvciAodmFyIGkgPSAwOyBpIDwgaXRlbXMubGVuZ3RoOyBpKyspIHtcblx0XHQgIHZhciBjdXJyZW50ID0gaXRlbXNbaV0uc3BsaXQoJzonKTtcblx0XHQgIHZhciBmaXJzdCA9IGN1cnJlbnRbMF0udHJpbSgpXG5cdFx0ICBqc29uU3RyaWcgKz0gJ1wiJyArIGZpcnN0ICsgJ1wiOlwiJyArIGN1cnJlbnRbMV0gKyAnXCIsJztcblx0XHR9XG5cdFx0anNvblN0cmlnID0ganNvblN0cmlnLnN1YnN0cigwLCBqc29uU3RyaWcubGVuZ3RoIC0gMSk7XG5cdFx0anNvblN0cmlnICs9ICd9XSc7XG5cdFx0dmFyIG9iaiA9IEpTT04ucGFyc2UoanNvblN0cmlnKTtcblx0XHRyZXR1cm4gb2JqXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRyZXR1cm4gdW5kZWZpbmVkXG5cdFx0fVxufTtcblxuXG5NZXRlb3IubWV0aG9kcyh7XG5cdFx0XHQnUmlkZXNEQi5kZWxldGUnIChJRCkge1xuXHRcdFx0XHRpZiAoIXRoaXMudXNlcklkKSB7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5lcnJvcignbm90IGF1dGhlcml6ZWQnKVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGZvciAodmFyIGkgPSBJRC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coJ3JlbW92ZWQgaWQ6ICcrIElEW2ldKVxuXHRcdFx0XHRcdFx0UmlkZXNEQi5yZW1vdmUoe19pZDogSURbaV19KVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblxuXHRcdFx0fSwnUmlkZXNEQi51cGRhdGUnIChyaWRlSWQscm93KSB7XG5cdFx0XHRcdGlmICghdGhpcy51c2VySWQpIHtcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLmVycm9yKCdub3QgYXV0aGVyaXplZCcpXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0UmlkZXNEQi51cGRhdGUocmlkZUlkLHJvdylcblx0XHRcdFx0fVxuXG5cdFx0XHR9LCdSaWRlc0RCLmluc2VydCcgKG5ld1JpZGUpIHtcblx0XHRcdFx0aWYgKCF0aGlzLnVzZXJJZCkge1xuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuZXJyb3IoJ25vdCBhdXRoZXJpemVkJylcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRSaWRlc0RCLmluc2VydChuZXdSaWRlKVxuXHRcdFx0XHR9XG5cblx0XHRcdH0sXG5cdFx0XHRnb29nbGVTeW5jKCkge1xuXHRcdFx0XHRpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdFx0XHRcdFx0bGV0IGN1cnJlbnRUaW1lID0gbW9tZW50KCkuZm9ybWF0KCdZWVlZLU1NLUREVEhIOm1tOnNzWicpXG5cdFx0XHRcdFx0bGV0IHBhcmFtcyA9IHtcblx0XHRcdFx0XHRcdHRpbWVNaW46IG1vbWVudCgnTWF5IDE2LCAyMDE4JykuZm9ybWF0KCdZWVlZLU1NLUREVEhIOm1tOnNzWicpLFxuXHRcdFx0XHRcdFx0bWF4UmVzdWx0czogMjUwMCxcblx0XHRcdFx0XHRcdC8vIHRpbWVNYXg6ICcyMDE3LTA1LTI1VDIyOjAwOjAwKzA4OjAwJyxcblx0XHRcdFx0XHRcdC8vIHE6ICdxdWVyeSB0ZXJtJyxcblx0XHRcdFx0XHRcdC8vIHNpbmdsZUV2ZW50czogdHJ1ZSxcblx0XHRcdFx0XHRcdC8vIG9yZGVyQnk6ICdzdGFydFRpbWUnXG5cdFx0XHRcdFx0fTsgLy9PcHRpb25hbCBxdWVyeSBwYXJhbWV0ZXJzIHJlZmVyZW5jaW5nIGdvb2dsZSBBUElzXG5cdFx0XHRcdFx0bGV0IGNhbGVuZGFySWQgPSAnaW5mby50aGlqbS5lY3NAZ21haWwuY29tJ1xuXG5cdFx0XHRcdFx0Z2V0Q2FsID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChmdW5jdGlvbihqc29uKSB7XG5cblx0XHRcdFx0XHR9LCBmdW5jdGlvbihlKSB7XG5cdFx0XHRcdFx0XHR0aHJvdyBlXG5cdFx0XHRcdFx0fSlcblxuXHRcdFx0XHRcdGNhbC5FdmVudHMubGlzdChjYWxlbmRhcklkLCBwYXJhbXMpXG5cdFx0XHRcdFx0XHQudGhlbihNZXRlb3IuYmluZEVudmlyb25tZW50KGZ1bmN0aW9uKGpzb24pIHtcblx0XHRcdFx0XHRcdFx0XHRmb3IgKHZhciBpID0ganNvbi5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0XHRcdFx0XHRcdFx0bW9tZW50LmxvY2FsZSgnbmwnKTtcblx0XHRcdFx0XHRcdFx0XHRcdHZhciBkYXRlRnVsbCA9IGpzb25baV0uc3RhcnQuZGF0ZVRpbWVcblx0XHRcdFx0XHRcdFx0XHRcdHZhciBkYXRlID0gbmV3IERhdGUoanNvbltpXS5zdGFydC5kYXRlVGltZSlcblx0XHRcdFx0XHRcdFx0XHRcdHZhciBkYXR1bSA9IG1vbWVudChqc29uW2ldLnN0YXJ0LmRhdGVUaW1lKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpXG5cdFx0XHRcdFx0XHRcdFx0XHR2YXIgdGltZSA9IG1vbWVudChqc29uW2ldLnN0YXJ0LmRhdGVUaW1lKS5mb3JtYXQoJ0hIOm1tJylcblx0XHRcdFx0XHRcdFx0XHRcdFxuXHRcdFx0XHRcdFx0XHRcdFx0YWRkVG90YWwoanNvbltpXS5sb2NhdGlvbilcblx0XHRcdFx0XHRcdFx0XHRcdGFkZFRvdGFsKGpzb25baV0uc3VtbWFyeSlcblx0XHRcdFx0XHRcdFx0XHRcdGFkZFRvdGFsKGpzb25baV0uZGVzY3JpcHRpb24pXG5cblx0XHRcdFx0XHRcdFx0XHRcdGlmKHRvdGFsLmtvc3RlbnBsYWF0cyA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHRvdGFsLmtvc3RlbnBsYWF0cyA9ICdvcCByZWtlbmluZydcblx0XHRcdFx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0XHRcdFx0aWYoISEhUmlkZXNEQi5maW5kKHtjYWxJZDoganNvbltpXS5pZH0pLmNvdW50KCkpIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0UmlkZXNEQi5pbnNlcnQoe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNhbElkIDoganNvbltpXS5pZCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRkYXRlRnVsbDogZGF0ZUZ1bGwsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0ZGF0ZTogZGF0ZSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRkYXR1bTogZGF0dW0sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dGltZTogdGltZSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRiZWRyaWpmOiB0b3RhbC5iZWRyaWpmLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHBhc3NhZ2llcjogdG90YWwucGFzc2FnaWVyLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGxvY2F0aWU6IGpzb25baV0ubG9jYXRpb24sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmFuOiB0b3RhbC52YW4sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0bmFhcjogdG90YWwubmFhcixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0aXRlbDoganNvbltpXS5zdW1tYXJ5LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGJlc2NocmlqdmluZzoganNvbltpXS5kZXNjcmlwdGlvbixcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0ZWw6IHRvdGFsLnRlbCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRrb3N0ZW5wbGFhdHM6IHRvdGFsLmtvc3RlbnBsYWF0cyxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjb21tZW50czogdG90YWwuY29tbWVudHNcblxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0bGV0IGNhbCA9IFJpZGVzREIuZmluZE9uZSh7Y2FsSWQ6IGpzb25baV0uaWR9KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgX2lkID0gY2FsLl9pZDtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IGJlc3R1dXJkZXIgPSBjYWwuYmVzdHV1cmRlcjtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IHRpdGVsID0ganNvbltpXS5zdW1tYXJ5O1xuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBsZXQgYmVzY2hyaWp2aW5nID0ganNvbltpXS5kZXNjcmlwdGlvbjtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IGxvY2F0aWUgPSBqc29uW2ldLmxvY2F0aW9uO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBsZXQgdmFuID0gY2FsLnZhbjtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IG5hYXIgPSBjYWwubmFhcjtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IHRlbCA9IGNhbC50ZWxcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IGJlZHJpamYgPSBjYWwuYmVkcmlqZjtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IGtvc3RlbiA9IGNhbC5rb3N0ZW47XG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIGxldCBrb3N0ZW5wbGFhdHMgPSBjYWwua29zdGVucGxhYXRzO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBsZXQgcm9hZHNob3cgPSBjYWwucm9hZHNob3dcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IHdhY2h0dGlqZCA9IGNhbC53YWNodHRpamRcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gbGV0IGNvbW1lbnRzID0gY2FsLmNvbW1lbnRzXG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIGxldCBwYXNzYWdpZXIgPSBjYWwucGFzc2FnaWVyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIGxldCBhZ2VuZGFwdW50ID0ge3ZhbjogdmFuLHBhc3NhZ2llcjogcGFzc2FnaWVyLCBjb21tZW50czogY29tbWVudHMsIHRlbDogdGVsLCBiZXNjaHJpanZpbmc6IGJlc2NocmlqdmluZywgdGl0ZWw6IHRpdGVsLCBuYWFyOiBuYWFyLCBjYWxJZDoganNvbltpXS5pZCxkYXRlRnVsbDogZGF0ZUZ1bGwsIGRhdGU6IGRhdGUsdGltZTogdGltZSwgYmVzdHV1cmRlcjogYmVzdHV1cmRlciwgbG9jYXRpZTogbG9jYXRpZSxiZWRyaWpmOiBiZWRyaWpmLGtvc3Rlbjoga29zdGVuLCBrb3N0ZW5wbGFhdHM6IGtvc3RlbnBsYWF0cyxyb2Fkc2hvdzogcm9hZHNob3csd2FjaHR0aWpkOiB3YWNodHRpamR9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIC8vIGNvbnNvbGUubG9nKCdqc29uOiAnKVxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyAvLyBjb25zb2xlLmxvZyhqc29uW2ldLnN1bW1hcnkpXG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIC8vIGNvbnNvbGUubG9nKCdhZ2VuZGFwdW50OiAnKVxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyAvLyBjb25zb2xlLmxvZyhhZ2VuZGFwdW50KVxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBSaWRlc0RCLnVwZGF0ZShfaWQsYWdlbmRhcHVudClcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gUmlkZXNEQi51cGRhdGUoX2lkLHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdGNhbElkIDoganNvbltpXS5pZCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdGRhdGVGdWxsOiBkYXRlRnVsbCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdGRhdGU6IGRhdGUsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIFx0XHR0aW1lOiB0aW1lLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBcdFx0ZGF0dW06IGRhdHVtLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBcdFx0YmVkcmlqZjogdG90YWwuYmVkcmlqZixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdHBhc3NhZ2llcjogdG90YWwucGFzc2FnaWVyLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBcdFx0bG9jYXRpZToganNvbltpXS5sb2NhdGlvbixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdHZhbjogdG90YWwudmFuLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBcdFx0bmFhcjogdG90YWwubmFhcixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdHRpdGVsOiBqc29uW2ldLnN1bW1hcnksXG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIFx0XHRiZXNjaHJpanZpbmc6IGpzb25baV0uZGVzY3JpcHRpb24sXG5cdFx0XHRcdFx0XHRcdFx0XHRcdC8vIFx0XHR0ZWw6IHRvdGFsLnRlbCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdGtvc3RlbnBsYWF0czogdG90YWwua29zdGVucGxhYXRzLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBcdFx0Y29tbWVudHM6IHRvdGFsLmNvbW1lbnRzLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBcdFx0d2FjaHR0aWpkOiBjYWwud2FjaHR0aWpkLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBcdFx0cm9hZHNob3c6IGNhbC5yb2Fkc2hvdyxcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdGtvc3RlbjogY2FsLmtvc3Rlbixcblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHRcdGJlc3R1dXJkZXI6IGNhbC5iZXN0dXVyZGVyXG5cblx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gXHR9KVxuXG5cdFx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdFx0XHR0b3RhbCA9IHt9XG5cdFx0XHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4ganNvblxuXG5cdFx0XHRcdFx0XHRcdH0sIGZ1bmN0aW9uKGUpIHtcblx0XHRcdFx0XHRcdFx0XHR0aHJvdyBlXG5cdFx0XHRcdFx0XHRcdH0pKVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQWNjb3VudHMgfVxuZnJvbSAnbWV0ZW9yL2FjY291bnRzLWJhc2UnXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBSb2xlcyB9IGZyb20gJ21ldGVvci9hbGFubmluZzpyb2xlcyc7XG5pbXBvcnQgeyBSaWRlc0RCIH0gZnJvbSAnLi8uLi9pbXBvcnRzL2FwaS9yaWRlcydcbmltcG9ydCB7IENsaWVudHMgfSBmcm9tICcuLy4uL2ltcG9ydHMvYXBpL2NsaWVudHMnXG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgUmlkZXNEQi5yZW1vdmUoe30pXG5cdC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG5BY2NvdW50cy52YWxpZGF0ZU5ld1VzZXIoKHVzZXIpID0+IHtcbiAgICBjb25zdCBlbWFpbCA9IHVzZXIuZW1haWxzWzBdLmFkZHJlc3M7XG5cbiAgICB0cnkge1xuICAgICAgbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgICAgIGVtYWlsOiB7XG4gICAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAgIHJlZ0V4OiBTaW1wbGVTY2hlbWEuUmVnRXguRW1haWxcbiAgICAgICAgfVxuICAgICAgfSkudmFsaWRhdGUoeyBlbWFpbCB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgZS5tZXNzYWdlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG5cblx0QWNjb3VudHMub25DcmVhdGVVc2VyKChvcHRpb25zLCB1c2VyKSA9PiB7XG5cdFx0dXNlci5wcm9maWxlID0ge3JvbGU6IG9wdGlvbnMucHJvZmlsZS5yb2xlfVxuXHRcdHJldHVybiB1c2VyXG5cdH0pXG5cblxufSk7XG4iXX0=
