var require = meteorInstall({"imports":{"api":{"google":{"Settings.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// imports/api/google/Settings.js                                                       //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
const key = require('./taxiapp-60d0eb253959.json').private_key;

const SERVICE_ACCT_ID = 'taxiapp@taxiapp-200711.iam.gserviceaccount.com';
const CALENDAR_URL = 'https://calendar.google.com/calendar?cid=aXQ5MGRxcTQzcTNyYXRxMjQ4dDRlcWhyZDBAZ3JvdXAuY2FsZW5kYXIuZ29vZ2xlLmNvbQ';
const CALENDAR_ID = {
  'primary': 'it90dqq43q3ratq248t4eqhrd0@group.calendar.google.com',
  'calendar-1': 'it90dqq43q3ratq248t4eqhrd0@group.calendar.google.com'
};
const TIMEZONE = 'GMT+02:00';
module.exports.calendarUrl = CALENDAR_URL;
module.exports.serviceAcctId = SERVICE_ACCT_ID;
module.exports.calendarId = CALENDAR_ID;
module.exports.key = key;
module.exports.timezone = TIMEZONE;
//////////////////////////////////////////////////////////////////////////////////////////

},"taxiapp-60d0eb253959.json":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// imports/api/google/taxiapp-60d0eb253959.json                                         //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
module.exports = {
  "type": "service_account",
  "project_id": "taxiapp-200711",
  "private_key_id": "60d0eb25395967b457f13aacd3ea1a179822640d",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCTuMCg7rpChsAH\nKYyKsiIl9DURB3R95IBe2qHfAkIIRAGaVR629aYOEfJrDR8cmsnzATJzeZxq9V49\njW+rhPagHvOg5GWt+ZCBeOYUvTjQ/Ho3ys9tKIdkGH/CmWvL5JQLLLXLojuUqz2v\npGzjlZsha0ln2M0Ujtosx2Md6GGw4hZ2fFfUsJTY78uSxhDgt3tYDZhyzseVKXc9\ngd0Pny1A67mZRNRMKYieRMyNdvtYolCcWUWk0b4komKhx7/RRFlzfBo9qPYUxMXZ\n/mD5HIjB4DKtx/6pSPSQLsUW7J1oRZM0hzSqSk9E8rrKPJLz7Qtox7nadBWX4ir6\nhnOFT+k1AgMBAAECggEACIbBsZhN7nCWLWOnzcqd33hyxq6aOfkCMtdmP/fCpXT9\nbbHLkc5ofQfqqOSrPsytauYPCizDC0Zp394ly63jSVc4Azmjp9DPlzWJ/Dj2ylNE\nX6uIYPnVpMCoQSx3VR+2rtVwEdalnz1qFFUGhvVX7KwjYsfYAH+FVs/UaAHFf77a\ni0uC47TmZFCPrilBBq4FewlXtF/IHZ6RQ7XbG/RjaQVPDF6tHmlKj06yu2QKfsbs\n+VT2qzMrsVyuESzYUeOheT4izPgsgEywqduFFynXuDn76smo1vGmTIOf70FOYvvF\nZJ89a2nQhv1BKl203aYQMPuUuqXFtchAZjEWkoJCMQKBgQDKH/4l4NKlajq/vjwp\nD8BpEEEEQhwG586F5cgNug4Dh6D+4IJSSygE4S6PEKNtqJCIw6xJaPWWJqvZKufF\nydhuAn/hWfpnf5G1mg3LXg9HXUxbPcF5ykCW5XGWYJrx/WBuSGUWlU7gaXWXVZa3\n0hF1ocol2tX0ipd6V3FNzuo2EQKBgQC7GIyQT8A4EVW+CfkZ0O2WAdWhjvRUvcES\nuMgNCI1mMriURRZB12ziSq5BAC7oB7b6D6qZhJJHUtqTJtq7bhsS0flTfuXMl6gc\naUb1fVjBaeBSfMKdZYnqGYd36VjZvSTnLPUgl66KZdDPFv5TgM+8WWwT/dL+UE9l\n6Pm4hzjM5QKBgQDA2EVjXl2b9P6YcqhzhNPPafKeXXTgIcqpddKpRhqYw46Xnxy3\n530HKtGBLh6/QVSlKAv4/mtSFxNe39DCpRIZ48ie+XovxUcAPTtsDRIGxL1VUFaI\nHLADSGZXU1SCDX0zu163bT0UX4oSGVbzizmdQf/cni4EYzajQ0qXMhPEAQKBgG5T\nAogSTuGA71N5ZAciGQcsm8GBn3fc0N3uUiDFW0PZQthDiOVYV590tB4mMoKmEfKQ\njGOsNemS5MqCzdZaDeLiKChhGray8vGV7r7RpCWg/iMF6GiRuGpvlV9THQ6AJyOe\ncgk/CDAZ67BB+cRZn6WMAVwkf2dxCfCpGaADNK41AoGBAL+dGa9fqOfsKV4fxaQ4\ni1oXS2/5/x4GtR50U2pW5PoSyStb625p+emiPNxXGNX+lsgQ70RS5WW99YX/xUrb\nZnJZPH9r4ylcl1BhtMv3/5glFaZgXRWR0egu/m/nloYhUHCiR3M6Ki+8IcYworDX\npDsO74DpNpWgdxgJQZUKQb3/\n-----END PRIVATE KEY-----\n",
  "client_email": "taxiapp@taxiapp-200711.iam.gserviceaccount.com",
  "client_id": "116018972731339785368",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://accounts.google.com/o/oauth2/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/taxiapp%40taxiapp-200711.iam.gserviceaccount.com"
};

//////////////////////////////////////////////////////////////////////////////////////////

}},"clients.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// imports/api/clients.js                                                               //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
module.export({
  Clients: () => Clients
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
const Clients = new Mongo.Collection('clients');

if (Meteor.isServer) {
  Meteor.publish('Clients', function () {
    console.log(this.userId);

    if (!!this.userId) {
      console.log('test');
      return Clients.find();
    }
  }); // 	var clientList = ["90/24 Sports"
  // ,"Amsterdam Redefined"
  // ,"Atricure"
  // ,"Avega"
  // ,"De Baker Kraamzorg"
  // ,"BAM"
  // ,"Blackrock"
  // ,"Blastradius"
  // ,"Boston Scientific"
  // ,"Brinkmansbeheer"
  // ,"Bunzl"
  // ,"Edelman"
  // ,"Cisi Care"
  // ,"Edison"
  // ,"Equinix"
  // ,"Equinix Nederland"
  // ,"H.I.G."
  // ,"Hoshizaki"
  // ,"Iamsterdam"
  // ,"Johnson&Johnson"
  // ,"Kraam en Co"
  // ,"Mammae Mia"
  // ,"Mirabeau"
  // ,"MSREF"
  // ,"Mylan"
  // ,"Novagraaf"
  // ,"Orange Connect"
  // ,"Pepperminds"
  // ,"Randstad Holding"
  // ,"Mw. A. Schwartz"
  // ,"Service Now"
  // ,"SMS Oncology"
  // ,"South Stream"
  // ,"Stryker"
  // ,"Stryker Flexim"
  // ,"UBS"
  // ,"Uniqure"
  // ,"Zin Kraamzorg"]
  // 	for (var i = clientList.length - 1; i >= 0; i--) {
  // 		Clients.insert({bedrijf: clientList[i]})
  // 	};
}

;
Meteor.methods({
  'Clients.delete'(ID) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      for (var i = ID.length - 1; i >= 0; i--) {
        console.log('removed id: ' + ID[i]);
        Clients.remove({
          _id: ID[i]
        });
      }

      ;
    }
  },

  'Clients.update'(rideId, row) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      Clients.update(rideId, row);
    }
  },

  'Clients.insert'(newRide) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      Clients.insert(newRide);
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////

},"rides.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// imports/api/rides.js                                                                 //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
module.export({
  RidesDB: () => RidesDB
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let CalendarAPI;
module.watch(require("node-google-calendar"), {
  default(v) {
    CalendarAPI = v;
  }

}, 2);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 3);

const CONFIG = require('./google/Settings');

let cal = new CalendarAPI(CONFIG);
const RidesDB = new Mongo.Collection('rides');

if (Meteor.isServer) {
  Meteor.publish('RidesDB', function () {
    if (!!this.userId) {
      return RidesDB.find();
    }
  });
}

;
Meteor.methods({
  'RidesDB.delete'(ID) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      for (var i = ID.length - 1; i >= 0; i--) {
        console.log('removed id: ' + ID[i]);
        RidesDB.remove({
          _id: ID[i]
        });
      }

      ;
    }
  },

  'RidesDB.update'(rideId, row) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      RidesDB.update(rideId, row);
    }
  },

  'RidesDB.insert'(newRide) {
    if (!this.userId) {
      throw new Meteor.error('not autherized');
    } else {
      RidesDB.insert(newRide);
    }
  },

  googleSync() {
    if (Meteor.isServer) {
      let params = {// timeMin: '2017-05-20T06:00:00+08:00',
        // timeMax: '2017-05-25T22:00:00+08:00',
        // q: 'query term',
        // singleEvents: true,
        // orderBy: 'startTime'
      }; //Optional query parameters referencing google APIs

      let calendarId = 'it90dqq43q3ratq248t4eqhrd0@group.calendar.google.com';
      getCal = Meteor.bindEnvironment(function (json) {}, function (e) {
        throw e;
      });
      cal.Events.list(calendarId, params).then(Meteor.bindEnvironment(function (json) {
        for (var i = json.length - 1; i >= 0; i--) {
          // console.log(json[i])
          var date = moment(json[i].start.dateTime).format();
          console.log(!!!RidesDB.find({
            calId: json[i].id
          }).count());

          if (!!!RidesDB.find({
            calId: json[i].id
          }).count()) {
            RidesDB.insert({
              calId: json[i].id,
              date: date,
              locatie: json[i].location,
              bedrijf: json[i].summary
            });
          } else {
            let cal = RidesDB.findOne({
              calId: json[i].id
            });
            let _id = cal._id;
            let bestuurder = cal.bestuurder;
            let locatie = cal.locatie;
            let bedrijf = cal.bedrijf;
            let inzittende = cal.inzittende;
            let kosten = cal.kosten;
            let kostenplaats = cal.kostenplaats;
            let roadshow = cal.roadshow;
            let wachttijd = cal.wachttijd;
            let agendapunt = {
              calId: json[i].id,
              date: date,
              bestuurder: bestuurder,
              locatie: locatie,
              bedrijf: bedrijf,
              inzittende: inzittende,
              kosten: kosten,
              kostenplaats: kostenplaats,
              roadshow: roadshow,
              wachttijd: wachttijd
            };
            console.log(json[i].id);
            console.log(agendapunt);
            RidesDB.update(_id, agendapunt);
          }
        }

        ;
        return json;
      }, function (e) {
        throw e;
      }));
    }
  }

});
//////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/main.js                                                                       //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let SimpleSchema;
module.watch(require("simpl-schema"), {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Roles;
module.watch(require("meteor/alanning:roles"), {
  Roles(v) {
    Roles = v;
  }

}, 3);
let RidesDB;
module.watch(require("./../imports/api/rides"), {
  RidesDB(v) {
    RidesDB = v;
  }

}, 4);
let Clients;
module.watch(require("./../imports/api/clients"), {
  Clients(v) {
    Clients = v;
  }

}, 5);
Meteor.startup(() => {
  // code to run on server at startup
  Accounts.validateNewUser(user => {
    const email = user.emails[0].address;

    try {
      new SimpleSchema({
        email: {
          type: String,
          regEx: SimpleSchema.RegEx.Email
        }
      }).validate({
        email
      });
    } catch (e) {
      throw new Meteor.Error(400, e.message);
    }

    return true;
  });
  Accounts.onCreateUser((options, user) => {
    user.profile = {
      role: options.profile.role
    };
    return user;
  });
});
//////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZ29vZ2xlL1NldHRpbmdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jbGllbnRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yaWRlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsia2V5IiwicmVxdWlyZSIsInByaXZhdGVfa2V5IiwiU0VSVklDRV9BQ0NUX0lEIiwiQ0FMRU5EQVJfVVJMIiwiQ0FMRU5EQVJfSUQiLCJUSU1FWk9ORSIsIm1vZHVsZSIsImV4cG9ydHMiLCJjYWxlbmRhclVybCIsInNlcnZpY2VBY2N0SWQiLCJjYWxlbmRhcklkIiwidGltZXpvbmUiLCJleHBvcnQiLCJDbGllbnRzIiwiTW9uZ28iLCJ3YXRjaCIsInYiLCJNZXRlb3IiLCJDb2xsZWN0aW9uIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwiY29uc29sZSIsImxvZyIsInVzZXJJZCIsImZpbmQiLCJtZXRob2RzIiwiSUQiLCJlcnJvciIsImkiLCJsZW5ndGgiLCJyZW1vdmUiLCJfaWQiLCJyaWRlSWQiLCJyb3ciLCJ1cGRhdGUiLCJuZXdSaWRlIiwiaW5zZXJ0IiwiUmlkZXNEQiIsIkNhbGVuZGFyQVBJIiwiZGVmYXVsdCIsIm1vbWVudCIsIkNPTkZJRyIsImNhbCIsImdvb2dsZVN5bmMiLCJwYXJhbXMiLCJnZXRDYWwiLCJiaW5kRW52aXJvbm1lbnQiLCJqc29uIiwiZSIsIkV2ZW50cyIsImxpc3QiLCJ0aGVuIiwiZGF0ZSIsInN0YXJ0IiwiZGF0ZVRpbWUiLCJmb3JtYXQiLCJjYWxJZCIsImlkIiwiY291bnQiLCJsb2NhdGllIiwibG9jYXRpb24iLCJiZWRyaWpmIiwic3VtbWFyeSIsImZpbmRPbmUiLCJiZXN0dXVyZGVyIiwiaW56aXR0ZW5kZSIsImtvc3RlbiIsImtvc3RlbnBsYWF0cyIsInJvYWRzaG93Iiwid2FjaHR0aWpkIiwiYWdlbmRhcHVudCIsIkFjY291bnRzIiwiU2ltcGxlU2NoZW1hIiwiUm9sZXMiLCJzdGFydHVwIiwidmFsaWRhdGVOZXdVc2VyIiwidXNlciIsImVtYWlsIiwiZW1haWxzIiwiYWRkcmVzcyIsInR5cGUiLCJTdHJpbmciLCJyZWdFeCIsIlJlZ0V4IiwiRW1haWwiLCJ2YWxpZGF0ZSIsIkVycm9yIiwibWVzc2FnZSIsIm9uQ3JlYXRlVXNlciIsIm9wdGlvbnMiLCJwcm9maWxlIiwicm9sZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxNQUFNQSxNQUFNQyxRQUFRLDZCQUFSLEVBQXVDQyxXQUFuRDs7QUFHQSxNQUFNQyxrQkFBa0IsZ0RBQXhCO0FBQ0EsTUFBTUMsZUFBZSxpSEFBckI7QUFDQSxNQUFNQyxjQUFjO0FBQ25CLGFBQVcsc0RBRFE7QUFFbkIsZ0JBQWM7QUFGSyxDQUFwQjtBQUlBLE1BQU1DLFdBQVcsV0FBakI7QUFFQUMsT0FBT0MsT0FBUCxDQUFlQyxXQUFmLEdBQTZCTCxZQUE3QjtBQUNBRyxPQUFPQyxPQUFQLENBQWVFLGFBQWYsR0FBK0JQLGVBQS9CO0FBQ0FJLE9BQU9DLE9BQVAsQ0FBZUcsVUFBZixHQUE0Qk4sV0FBNUI7QUFDQUUsT0FBT0MsT0FBUCxDQUFlUixHQUFmLEdBQXFCQSxHQUFyQjtBQUNBTyxPQUFPQyxPQUFQLENBQWVJLFFBQWYsR0FBMEJOLFFBQTFCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmQUMsT0FBT00sTUFBUCxDQUFjO0FBQUNDLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUlDLEtBQUo7QUFBVVIsT0FBT1MsS0FBUCxDQUFhZixRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDYyxRQUFNRSxDQUFOLEVBQVE7QUFBQ0YsWUFBTUUsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJQyxNQUFKO0FBQVdYLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2lCLFNBQU9ELENBQVAsRUFBUztBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRy9HLE1BQU1ILFVBQVUsSUFBSUMsTUFBTUksVUFBVixDQUFxQixTQUFyQixDQUFoQjs7QUFHUCxJQUFJRCxPQUFPRSxRQUFYLEVBQXFCO0FBQ3BCRixTQUFPRyxPQUFQLENBQWUsU0FBZixFQUEwQixZQUFXO0FBQ3BDQyxZQUFRQyxHQUFSLENBQVksS0FBS0MsTUFBakI7O0FBQ0EsUUFBSSxDQUFDLENBQUMsS0FBS0EsTUFBWCxFQUFtQjtBQUNsQkYsY0FBUUMsR0FBUixDQUFZLE1BQVo7QUFDQSxhQUFPVCxRQUFRVyxJQUFSLEVBQVA7QUFDQTtBQUNELEdBTkQsRUFEb0IsQ0FRckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNDOztBQUFBO0FBRURQLE9BQU9RLE9BQVAsQ0FBZTtBQUNaLG1CQUFrQkMsRUFBbEIsRUFBc0I7QUFDckIsUUFBSSxDQUFDLEtBQUtILE1BQVYsRUFBa0I7QUFDakIsWUFBTSxJQUFJTixPQUFPVSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ04sV0FBSyxJQUFJQyxJQUFJRixHQUFHRyxNQUFILEdBQVksQ0FBekIsRUFBNEJELEtBQUssQ0FBakMsRUFBb0NBLEdBQXBDLEVBQXlDO0FBQ3hDUCxnQkFBUUMsR0FBUixDQUFZLGlCQUFnQkksR0FBR0UsQ0FBSCxDQUE1QjtBQUNBZixnQkFBUWlCLE1BQVIsQ0FBZTtBQUFDQyxlQUFLTCxHQUFHRSxDQUFIO0FBQU4sU0FBZjtBQUNBOztBQUFBO0FBQ0Q7QUFFRCxHQVhXOztBQVdWLG1CQUFrQkksTUFBbEIsRUFBeUJDLEdBQXpCLEVBQThCO0FBQy9CLFFBQUksQ0FBQyxLQUFLVixNQUFWLEVBQWtCO0FBQ2pCLFlBQU0sSUFBSU4sT0FBT1UsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBLEtBRkQsTUFFTztBQUNOZCxjQUFRcUIsTUFBUixDQUFlRixNQUFmLEVBQXNCQyxHQUF0QjtBQUNBO0FBRUQsR0FsQlc7O0FBa0JWLG1CQUFrQkUsT0FBbEIsRUFBMkI7QUFDNUIsUUFBSSxDQUFDLEtBQUtaLE1BQVYsRUFBa0I7QUFDakIsWUFBTSxJQUFJTixPQUFPVSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ05kLGNBQVF1QixNQUFSLENBQWVELE9BQWY7QUFDQTtBQUVEOztBQXpCVyxDQUFmLEU7Ozs7Ozs7Ozs7O0FDMURBN0IsT0FBT00sTUFBUCxDQUFjO0FBQUN5QixXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJdkIsS0FBSjtBQUFVUixPQUFPUyxLQUFQLENBQWFmLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNjLFFBQU1FLENBQU4sRUFBUTtBQUFDRixZQUFNRSxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlDLE1BQUo7QUFBV1gsT0FBT1MsS0FBUCxDQUFhZixRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDaUIsU0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXNCLFdBQUo7QUFBZ0JoQyxPQUFPUyxLQUFQLENBQWFmLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDdUMsVUFBUXZCLENBQVIsRUFBVTtBQUFDc0Isa0JBQVl0QixDQUFaO0FBQWM7O0FBQTFCLENBQTdDLEVBQXlFLENBQXpFO0FBQTRFLElBQUl3QixNQUFKO0FBQVdsQyxPQUFPUyxLQUFQLENBQWFmLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUN1QyxVQUFRdkIsQ0FBUixFQUFVO0FBQUN3QixhQUFPeEIsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFJNVIsTUFBTXlCLFNBQVN6QyxRQUFRLG1CQUFSLENBQWY7O0FBRUEsSUFBSTBDLE1BQU0sSUFBSUosV0FBSixDQUFnQkcsTUFBaEIsQ0FBVjtBQUdPLE1BQU1KLFVBQVUsSUFBSXZCLE1BQU1JLFVBQVYsQ0FBcUIsT0FBckIsQ0FBaEI7O0FBRVAsSUFBSUQsT0FBT0UsUUFBWCxFQUFxQjtBQUNwQkYsU0FBT0csT0FBUCxDQUFlLFNBQWYsRUFBMEIsWUFBVztBQUNwQyxRQUFJLENBQUMsQ0FBQyxLQUFLRyxNQUFYLEVBQW1CO0FBQ2xCLGFBQU9jLFFBQVFiLElBQVIsRUFBUDtBQUNBO0FBQ0QsR0FKRDtBQUtBOztBQUFBO0FBRURQLE9BQU9RLE9BQVAsQ0FBZTtBQUNaLG1CQUFrQkMsRUFBbEIsRUFBc0I7QUFDckIsUUFBSSxDQUFDLEtBQUtILE1BQVYsRUFBa0I7QUFDakIsWUFBTSxJQUFJTixPQUFPVSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ04sV0FBSyxJQUFJQyxJQUFJRixHQUFHRyxNQUFILEdBQVksQ0FBekIsRUFBNEJELEtBQUssQ0FBakMsRUFBb0NBLEdBQXBDLEVBQXlDO0FBQ3hDUCxnQkFBUUMsR0FBUixDQUFZLGlCQUFnQkksR0FBR0UsQ0FBSCxDQUE1QjtBQUNBUyxnQkFBUVAsTUFBUixDQUFlO0FBQUNDLGVBQUtMLEdBQUdFLENBQUg7QUFBTixTQUFmO0FBQ0E7O0FBQUE7QUFDRDtBQUVELEdBWFc7O0FBV1YsbUJBQWtCSSxNQUFsQixFQUF5QkMsR0FBekIsRUFBOEI7QUFDL0IsUUFBSSxDQUFDLEtBQUtWLE1BQVYsRUFBa0I7QUFDakIsWUFBTSxJQUFJTixPQUFPVSxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ05VLGNBQVFILE1BQVIsQ0FBZUYsTUFBZixFQUFzQkMsR0FBdEI7QUFDQTtBQUVELEdBbEJXOztBQWtCVixtQkFBa0JFLE9BQWxCLEVBQTJCO0FBQzVCLFFBQUksQ0FBQyxLQUFLWixNQUFWLEVBQWtCO0FBQ2pCLFlBQU0sSUFBSU4sT0FBT1UsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNBLEtBRkQsTUFFTztBQUNOVSxjQUFRRCxNQUFSLENBQWVELE9BQWY7QUFDQTtBQUVELEdBekJXOztBQTBCWlEsZUFBYTtBQUNaLFFBQUkxQixPQUFPRSxRQUFYLEVBQXFCO0FBQ3BCLFVBQUl5QixTQUFTLENBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxZLE9BQWIsQ0FEb0IsQ0FPakI7O0FBQ0gsVUFBSWxDLGFBQWEsc0RBQWpCO0FBRUFtQyxlQUFTNUIsT0FBTzZCLGVBQVAsQ0FBdUIsVUFBU0MsSUFBVCxFQUFlLENBRTlDLENBRlEsRUFFTixVQUFTQyxDQUFULEVBQVk7QUFDZCxjQUFNQSxDQUFOO0FBQ0EsT0FKUSxDQUFUO0FBTUFOLFVBQUlPLE1BQUosQ0FBV0MsSUFBWCxDQUFnQnhDLFVBQWhCLEVBQTRCa0MsTUFBNUIsRUFDRU8sSUFERixDQUNPbEMsT0FBTzZCLGVBQVAsQ0FBdUIsVUFBU0MsSUFBVCxFQUFlO0FBQzFDLGFBQUssSUFBSW5CLElBQUltQixLQUFLbEIsTUFBTCxHQUFjLENBQTNCLEVBQThCRCxLQUFLLENBQW5DLEVBQXNDQSxHQUF0QyxFQUEyQztBQUMxQztBQUNBLGNBQUl3QixPQUFPWixPQUFPTyxLQUFLbkIsQ0FBTCxFQUFReUIsS0FBUixDQUFjQyxRQUFyQixFQUErQkMsTUFBL0IsRUFBWDtBQUNBbEMsa0JBQVFDLEdBQVIsQ0FBWSxDQUFDLENBQUMsQ0FBQ2UsUUFBUWIsSUFBUixDQUFhO0FBQUNnQyxtQkFBT1QsS0FBS25CLENBQUwsRUFBUTZCO0FBQWhCLFdBQWIsRUFBa0NDLEtBQWxDLEVBQWY7O0FBQ0EsY0FBRyxDQUFDLENBQUMsQ0FBQ3JCLFFBQVFiLElBQVIsQ0FBYTtBQUFDZ0MsbUJBQU9ULEtBQUtuQixDQUFMLEVBQVE2QjtBQUFoQixXQUFiLEVBQWtDQyxLQUFsQyxFQUFOLEVBQWlEO0FBQ2hEckIsb0JBQVFELE1BQVIsQ0FBZTtBQUNmb0IscUJBQVFULEtBQUtuQixDQUFMLEVBQVE2QixFQUREO0FBRWZMLG9CQUFNQSxJQUZTO0FBR2ZPLHVCQUFTWixLQUFLbkIsQ0FBTCxFQUFRZ0MsUUFIRjtBQUlmQyx1QkFBU2QsS0FBS25CLENBQUwsRUFBUWtDO0FBSkYsYUFBZjtBQU1BLFdBUEQsTUFPTztBQUNOLGdCQUFJcEIsTUFBTUwsUUFBUTBCLE9BQVIsQ0FBZ0I7QUFBQ1AscUJBQU9ULEtBQUtuQixDQUFMLEVBQVE2QjtBQUFoQixhQUFoQixDQUFWO0FBQ0EsZ0JBQUkxQixNQUFNVyxJQUFJWCxHQUFkO0FBQ0EsZ0JBQUlpQyxhQUFhdEIsSUFBSXNCLFVBQXJCO0FBQ0EsZ0JBQUlMLFVBQVVqQixJQUFJaUIsT0FBbEI7QUFDQSxnQkFBSUUsVUFBVW5CLElBQUltQixPQUFsQjtBQUNBLGdCQUFJSSxhQUFhdkIsSUFBSXVCLFVBQXJCO0FBQ0EsZ0JBQUlDLFNBQVN4QixJQUFJd0IsTUFBakI7QUFDQSxnQkFBSUMsZUFBZXpCLElBQUl5QixZQUF2QjtBQUNBLGdCQUFJQyxXQUFXMUIsSUFBSTBCLFFBQW5CO0FBQ0EsZ0JBQUlDLFlBQVkzQixJQUFJMkIsU0FBcEI7QUFDQSxnQkFBSUMsYUFBYTtBQUFDZCxxQkFBT1QsS0FBS25CLENBQUwsRUFBUTZCLEVBQWhCO0FBQW9CTCxvQkFBTUEsSUFBMUI7QUFBZ0NZLDBCQUFZQSxVQUE1QztBQUF3REwsdUJBQVNBLE9BQWpFO0FBQXlFRSx1QkFBU0EsT0FBbEY7QUFBMkZJLDBCQUFZQSxVQUF2RztBQUFrSEMsc0JBQVFBLE1BQTFIO0FBQWtJQyw0QkFBY0EsWUFBaEo7QUFBNkpDLHdCQUFVQSxRQUF2SztBQUFnTEMseUJBQVdBO0FBQTNMLGFBQWpCO0FBRUFoRCxvQkFBUUMsR0FBUixDQUFZeUIsS0FBS25CLENBQUwsRUFBUTZCLEVBQXBCO0FBQ0FwQyxvQkFBUUMsR0FBUixDQUFZZ0QsVUFBWjtBQUNBakMsb0JBQVFILE1BQVIsQ0FBZUgsR0FBZixFQUFtQnVDLFVBQW5CO0FBQ0E7QUFFRDs7QUFBQTtBQUNELGVBQU92QixJQUFQO0FBRUEsT0FqQ0ksRUFpQ0YsVUFBU0MsQ0FBVCxFQUFZO0FBQ2QsY0FBTUEsQ0FBTjtBQUNBLE9BbkNJLENBRFA7QUFxQ0U7QUFDRjs7QUFqRlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ25CQSxJQUFJL0IsTUFBSjtBQUFXWCxPQUFPUyxLQUFQLENBQWFmLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNpQixTQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJdUQsUUFBSjtBQUFhakUsT0FBT1MsS0FBUCxDQUFhZixRQUFRLHNCQUFSLENBQWIsRUFBNkM7QUFBQ3VFLFdBQVN2RCxDQUFULEVBQVc7QUFBQ3VELGVBQVN2RCxDQUFUO0FBQVc7O0FBQXhCLENBQTdDLEVBQXVFLENBQXZFO0FBQTBFLElBQUl3RCxZQUFKO0FBQWlCbEUsT0FBT1MsS0FBUCxDQUFhZixRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDdUMsVUFBUXZCLENBQVIsRUFBVTtBQUFDd0QsbUJBQWF4RCxDQUFiO0FBQWU7O0FBQTNCLENBQXJDLEVBQWtFLENBQWxFO0FBQXFFLElBQUl5RCxLQUFKO0FBQVVuRSxPQUFPUyxLQUFQLENBQWFmLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDeUUsUUFBTXpELENBQU4sRUFBUTtBQUFDeUQsWUFBTXpELENBQU47QUFBUTs7QUFBbEIsQ0FBOUMsRUFBa0UsQ0FBbEU7QUFBcUUsSUFBSXFCLE9BQUo7QUFBWS9CLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNxQyxVQUFRckIsQ0FBUixFQUFVO0FBQUNxQixjQUFRckIsQ0FBUjtBQUFVOztBQUF0QixDQUEvQyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJSCxPQUFKO0FBQVlQLE9BQU9TLEtBQVAsQ0FBYWYsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNhLFVBQVFHLENBQVIsRUFBVTtBQUFDSCxjQUFRRyxDQUFSO0FBQVU7O0FBQXRCLENBQWpELEVBQXlFLENBQXpFO0FBUXhhQyxPQUFPeUQsT0FBUCxDQUFlLE1BQU07QUFDcEI7QUFDREgsV0FBU0ksZUFBVCxDQUEwQkMsSUFBRCxJQUFVO0FBQy9CLFVBQU1DLFFBQVFELEtBQUtFLE1BQUwsQ0FBWSxDQUFaLEVBQWVDLE9BQTdCOztBQUVBLFFBQUk7QUFDRixVQUFJUCxZQUFKLENBQWlCO0FBQ2ZLLGVBQU87QUFDTEcsZ0JBQU1DLE1BREQ7QUFFTEMsaUJBQU9WLGFBQWFXLEtBQWIsQ0FBbUJDO0FBRnJCO0FBRFEsT0FBakIsRUFLR0MsUUFMSCxDQUtZO0FBQUVSO0FBQUYsT0FMWjtBQU1ELEtBUEQsQ0FPRSxPQUFPN0IsQ0FBUCxFQUFVO0FBQ1YsWUFBTSxJQUFJL0IsT0FBT3FFLEtBQVgsQ0FBaUIsR0FBakIsRUFBc0J0QyxFQUFFdUMsT0FBeEIsQ0FBTjtBQUNEOztBQUVELFdBQU8sSUFBUDtBQUNELEdBZkg7QUFpQkNoQixXQUFTaUIsWUFBVCxDQUFzQixDQUFDQyxPQUFELEVBQVViLElBQVYsS0FBbUI7QUFDeENBLFNBQUtjLE9BQUwsR0FBZTtBQUFDQyxZQUFNRixRQUFRQyxPQUFSLENBQWdCQztBQUF2QixLQUFmO0FBQ0EsV0FBT2YsSUFBUDtBQUNBLEdBSEQ7QUFNQSxDQXpCRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBrZXkgPSByZXF1aXJlKCcuL3RheGlhcHAtNjBkMGViMjUzOTU5Lmpzb24nKS5wcml2YXRlX2tleTtcblxuXG5jb25zdCBTRVJWSUNFX0FDQ1RfSUQgPSAndGF4aWFwcEB0YXhpYXBwLTIwMDcxMS5pYW0uZ3NlcnZpY2VhY2NvdW50LmNvbSc7XG5jb25zdCBDQUxFTkRBUl9VUkwgPSAnaHR0cHM6Ly9jYWxlbmRhci5nb29nbGUuY29tL2NhbGVuZGFyP2NpZD1hWFE1TUdSeGNUUXpjVE55WVhSeE1qUTRkRFJsY1doeVpEQkFaM0p2ZFhBdVkyRnNaVzVrWVhJdVoyOXZaMnhsTG1OdmJRJztcbmNvbnN0IENBTEVOREFSX0lEID0ge1xuXHQncHJpbWFyeSc6ICdpdDkwZHFxNDNxM3JhdHEyNDh0NGVxaHJkMEBncm91cC5jYWxlbmRhci5nb29nbGUuY29tJyxcblx0J2NhbGVuZGFyLTEnOiAnaXQ5MGRxcTQzcTNyYXRxMjQ4dDRlcWhyZDBAZ3JvdXAuY2FsZW5kYXIuZ29vZ2xlLmNvbSdcbn07XG5jb25zdCBUSU1FWk9ORSA9ICdHTVQrMDI6MDAnO1xuXG5tb2R1bGUuZXhwb3J0cy5jYWxlbmRhclVybCA9IENBTEVOREFSX1VSTDtcbm1vZHVsZS5leHBvcnRzLnNlcnZpY2VBY2N0SWQgPSBTRVJWSUNFX0FDQ1RfSUQ7XG5tb2R1bGUuZXhwb3J0cy5jYWxlbmRhcklkID0gQ0FMRU5EQVJfSUQ7XG5tb2R1bGUuZXhwb3J0cy5rZXkgPSBrZXk7XG5tb2R1bGUuZXhwb3J0cy50aW1lem9uZSA9IFRJTUVaT05FOyIsImltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuXG5leHBvcnQgY29uc3QgQ2xpZW50cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjbGllbnRzJylcblxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdE1ldGVvci5wdWJsaXNoKCdDbGllbnRzJywgZnVuY3Rpb24oKSB7XG5cdFx0Y29uc29sZS5sb2codGhpcy51c2VySWQpXG5cdFx0aWYgKCEhdGhpcy51c2VySWQpIHtcblx0XHRcdGNvbnNvbGUubG9nKCd0ZXN0Jylcblx0XHRcdHJldHVybiBDbGllbnRzLmZpbmQoKTtcblx0XHR9XG5cdH0pXG4vLyBcdHZhciBjbGllbnRMaXN0ID0gW1wiOTAvMjQgU3BvcnRzXCJcbi8vICxcIkFtc3RlcmRhbSBSZWRlZmluZWRcIlxuLy8gLFwiQXRyaWN1cmVcIlxuLy8gLFwiQXZlZ2FcIlxuLy8gLFwiRGUgQmFrZXIgS3JhYW16b3JnXCJcbi8vICxcIkJBTVwiXG4vLyAsXCJCbGFja3JvY2tcIlxuLy8gLFwiQmxhc3RyYWRpdXNcIlxuLy8gLFwiQm9zdG9uIFNjaWVudGlmaWNcIlxuLy8gLFwiQnJpbmttYW5zYmVoZWVyXCJcbi8vICxcIkJ1bnpsXCJcbi8vICxcIkVkZWxtYW5cIlxuLy8gLFwiQ2lzaSBDYXJlXCJcbi8vICxcIkVkaXNvblwiXG4vLyAsXCJFcXVpbml4XCJcbi8vICxcIkVxdWluaXggTmVkZXJsYW5kXCJcbi8vICxcIkguSS5HLlwiXG4vLyAsXCJIb3NoaXpha2lcIlxuLy8gLFwiSWFtc3RlcmRhbVwiXG4vLyAsXCJKb2huc29uJkpvaG5zb25cIlxuLy8gLFwiS3JhYW0gZW4gQ29cIlxuLy8gLFwiTWFtbWFlIE1pYVwiXG4vLyAsXCJNaXJhYmVhdVwiXG4vLyAsXCJNU1JFRlwiXG4vLyAsXCJNeWxhblwiXG4vLyAsXCJOb3ZhZ3JhYWZcIlxuLy8gLFwiT3JhbmdlIENvbm5lY3RcIlxuLy8gLFwiUGVwcGVybWluZHNcIlxuLy8gLFwiUmFuZHN0YWQgSG9sZGluZ1wiXG4vLyAsXCJNdy4gQS4gU2Nod2FydHpcIlxuLy8gLFwiU2VydmljZSBOb3dcIlxuLy8gLFwiU01TIE9uY29sb2d5XCJcbi8vICxcIlNvdXRoIFN0cmVhbVwiXG4vLyAsXCJTdHJ5a2VyXCJcbi8vICxcIlN0cnlrZXIgRmxleGltXCJcbi8vICxcIlVCU1wiXG4vLyAsXCJVbmlxdXJlXCJcbi8vICxcIlppbiBLcmFhbXpvcmdcIl1cblxuLy8gXHRmb3IgKHZhciBpID0gY2xpZW50TGlzdC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuLy8gXHRcdENsaWVudHMuaW5zZXJ0KHtiZWRyaWpmOiBjbGllbnRMaXN0W2ldfSlcbi8vIFx0fTtcbn07XG5cbk1ldGVvci5tZXRob2RzKHtcblx0XHRcdCdDbGllbnRzLmRlbGV0ZScgKElEKSB7XG5cdFx0XHRcdGlmICghdGhpcy51c2VySWQpIHtcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLmVycm9yKCdub3QgYXV0aGVyaXplZCcpXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0Zm9yICh2YXIgaSA9IElELmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZygncmVtb3ZlZCBpZDogJysgSURbaV0pXG5cdFx0XHRcdFx0XHRDbGllbnRzLnJlbW92ZSh7X2lkOiBJRFtpXX0pXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fVxuXG5cdFx0XHR9LCdDbGllbnRzLnVwZGF0ZScgKHJpZGVJZCxyb3cpIHtcblx0XHRcdFx0aWYgKCF0aGlzLnVzZXJJZCkge1xuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuZXJyb3IoJ25vdCBhdXRoZXJpemVkJylcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRDbGllbnRzLnVwZGF0ZShyaWRlSWQscm93KVxuXHRcdFx0XHR9XG5cblx0XHRcdH0sJ0NsaWVudHMuaW5zZXJ0JyAobmV3UmlkZSkge1xuXHRcdFx0XHRpZiAoIXRoaXMudXNlcklkKSB7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5lcnJvcignbm90IGF1dGhlcml6ZWQnKVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdENsaWVudHMuaW5zZXJ0KG5ld1JpZGUpXG5cdFx0XHRcdH1cblxuXHRcdFx0fVxuXHR9KTtcbiIsImltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbydcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuaW1wb3J0IENhbGVuZGFyQVBJIGZyb20gJ25vZGUtZ29vZ2xlLWNhbGVuZGFyJ1xuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnXG5jb25zdCBDT05GSUcgPSByZXF1aXJlKCcuL2dvb2dsZS9TZXR0aW5ncycpO1xuXG5sZXQgY2FsID0gbmV3IENhbGVuZGFyQVBJKENPTkZJRyk7XG5cblxuZXhwb3J0IGNvbnN0IFJpZGVzREIgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncmlkZXMnKVxuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdE1ldGVvci5wdWJsaXNoKCdSaWRlc0RCJywgZnVuY3Rpb24oKSB7XG5cdFx0aWYgKCEhdGhpcy51c2VySWQpIHtcblx0XHRcdHJldHVybiBSaWRlc0RCLmZpbmQoKTtcblx0XHR9XG5cdH0pXG59O1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cdFx0XHQnUmlkZXNEQi5kZWxldGUnIChJRCkge1xuXHRcdFx0XHRpZiAoIXRoaXMudXNlcklkKSB7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5lcnJvcignbm90IGF1dGhlcml6ZWQnKVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGZvciAodmFyIGkgPSBJRC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coJ3JlbW92ZWQgaWQ6ICcrIElEW2ldKVxuXHRcdFx0XHRcdFx0UmlkZXNEQi5yZW1vdmUoe19pZDogSURbaV19KVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblxuXHRcdFx0fSwnUmlkZXNEQi51cGRhdGUnIChyaWRlSWQscm93KSB7XG5cdFx0XHRcdGlmICghdGhpcy51c2VySWQpIHtcblx0XHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLmVycm9yKCdub3QgYXV0aGVyaXplZCcpXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0UmlkZXNEQi51cGRhdGUocmlkZUlkLHJvdylcblx0XHRcdFx0fVxuXG5cdFx0XHR9LCdSaWRlc0RCLmluc2VydCcgKG5ld1JpZGUpIHtcblx0XHRcdFx0aWYgKCF0aGlzLnVzZXJJZCkge1xuXHRcdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuZXJyb3IoJ25vdCBhdXRoZXJpemVkJylcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRSaWRlc0RCLmluc2VydChuZXdSaWRlKVxuXHRcdFx0XHR9XG5cblx0XHRcdH0sXG5cdFx0XHRnb29nbGVTeW5jKCkge1xuXHRcdFx0XHRpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cdFx0XHRcdFx0bGV0IHBhcmFtcyA9IHtcblx0XHRcdFx0XHRcdC8vIHRpbWVNaW46ICcyMDE3LTA1LTIwVDA2OjAwOjAwKzA4OjAwJyxcblx0XHRcdFx0XHRcdC8vIHRpbWVNYXg6ICcyMDE3LTA1LTI1VDIyOjAwOjAwKzA4OjAwJyxcblx0XHRcdFx0XHRcdC8vIHE6ICdxdWVyeSB0ZXJtJyxcblx0XHRcdFx0XHRcdC8vIHNpbmdsZUV2ZW50czogdHJ1ZSxcblx0XHRcdFx0XHRcdC8vIG9yZGVyQnk6ICdzdGFydFRpbWUnXG5cdFx0XHRcdFx0fTsgLy9PcHRpb25hbCBxdWVyeSBwYXJhbWV0ZXJzIHJlZmVyZW5jaW5nIGdvb2dsZSBBUElzXG5cdFx0XHRcdFx0bGV0IGNhbGVuZGFySWQgPSAnaXQ5MGRxcTQzcTNyYXRxMjQ4dDRlcWhyZDBAZ3JvdXAuY2FsZW5kYXIuZ29vZ2xlLmNvbSdcblxuXHRcdFx0XHRcdGdldENhbCA9IE1ldGVvci5iaW5kRW52aXJvbm1lbnQoZnVuY3Rpb24oanNvbikge1xuXG5cdFx0XHRcdFx0fSwgZnVuY3Rpb24oZSkge1xuXHRcdFx0XHRcdFx0dGhyb3cgZVxuXHRcdFx0XHRcdH0pXG5cblx0XHRcdFx0XHRjYWwuRXZlbnRzLmxpc3QoY2FsZW5kYXJJZCwgcGFyYW1zKVxuXHRcdFx0XHRcdFx0LnRoZW4oTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChmdW5jdGlvbihqc29uKSB7XG5cdFx0XHRcdFx0XHRcdFx0Zm9yICh2YXIgaSA9IGpzb24ubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRcdFx0XHRcdFx0XHRcdC8vIGNvbnNvbGUubG9nKGpzb25baV0pXG5cdFx0XHRcdFx0XHRcdFx0XHR2YXIgZGF0ZSA9IG1vbWVudChqc29uW2ldLnN0YXJ0LmRhdGVUaW1lKS5mb3JtYXQoKVxuXHRcdFx0XHRcdFx0XHRcdFx0Y29uc29sZS5sb2coISEhUmlkZXNEQi5maW5kKHtjYWxJZDoganNvbltpXS5pZH0pLmNvdW50KCkpXG5cdFx0XHRcdFx0XHRcdFx0XHRpZighISFSaWRlc0RCLmZpbmQoe2NhbElkOiBqc29uW2ldLmlkfSkuY291bnQoKSkge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRSaWRlc0RCLmluc2VydCh7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNhbElkIDoganNvbltpXS5pZCxcblx0XHRcdFx0XHRcdFx0XHRcdFx0ZGF0ZTogZGF0ZSxcblx0XHRcdFx0XHRcdFx0XHRcdFx0bG9jYXRpZToganNvbltpXS5sb2NhdGlvbixcblx0XHRcdFx0XHRcdFx0XHRcdFx0YmVkcmlqZjoganNvbltpXS5zdW1tYXJ5XG5cdFx0XHRcdFx0XHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgY2FsID0gUmlkZXNEQi5maW5kT25lKHtjYWxJZDoganNvbltpXS5pZH0pXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGxldCBfaWQgPSBjYWwuX2lkO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgYmVzdHV1cmRlciA9IGNhbC5iZXN0dXVyZGVyO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgbG9jYXRpZSA9IGNhbC5sb2NhdGllO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgYmVkcmlqZiA9IGNhbC5iZWRyaWpmO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgaW56aXR0ZW5kZSA9IGNhbC5pbnppdHRlbmRlO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQga29zdGVuID0gY2FsLmtvc3Rlbjtcblx0XHRcdFx0XHRcdFx0XHRcdFx0bGV0IGtvc3RlbnBsYWF0cyA9IGNhbC5rb3N0ZW5wbGFhdHM7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGxldCByb2Fkc2hvdyA9IGNhbC5yb2Fkc2hvd1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgd2FjaHR0aWpkID0gY2FsLndhY2h0dGlqZFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRsZXQgYWdlbmRhcHVudCA9IHtjYWxJZDoganNvbltpXS5pZCwgZGF0ZTogZGF0ZSwgYmVzdHV1cmRlcjogYmVzdHV1cmRlciwgbG9jYXRpZTogbG9jYXRpZSxiZWRyaWpmOiBiZWRyaWpmLCBpbnppdHRlbmRlOiBpbnppdHRlbmRlLGtvc3Rlbjoga29zdGVuLCBrb3N0ZW5wbGFhdHM6IGtvc3RlbnBsYWF0cyxyb2Fkc2hvdzogcm9hZHNob3csd2FjaHR0aWpkOiB3YWNodHRpamR9XG5cdFx0XHRcdFx0XHRcdFx0XHRcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y29uc29sZS5sb2coanNvbltpXS5pZClcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y29uc29sZS5sb2coYWdlbmRhcHVudClcblx0XHRcdFx0XHRcdFx0XHRcdFx0UmlkZXNEQi51cGRhdGUoX2lkLGFnZW5kYXB1bnQpXG5cdFx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdFx0XHRcblx0XHRcdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0XHRcdHJldHVybiBqc29uXG5cblx0XHRcdFx0XHRcdFx0fSwgZnVuY3Rpb24oZSkge1xuXHRcdFx0XHRcdFx0XHRcdHRocm93IGVcblx0XHRcdFx0XHRcdFx0fSkpXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9XG5mcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcbmltcG9ydCB7IFJpZGVzREIgfSBmcm9tICcuLy4uL2ltcG9ydHMvYXBpL3JpZGVzJ1xuaW1wb3J0IHsgQ2xpZW50cyB9IGZyb20gJy4vLi4vaW1wb3J0cy9hcGkvY2xpZW50cydcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuXHQvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxuQWNjb3VudHMudmFsaWRhdGVOZXdVc2VyKCh1c2VyKSA9PiB7XG4gICAgY29uc3QgZW1haWwgPSB1c2VyLmVtYWlsc1swXS5hZGRyZXNzO1xuXG4gICAgdHJ5IHtcbiAgICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgICBlbWFpbDoge1xuICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICByZWdFeDogU2ltcGxlU2NoZW1hLlJlZ0V4LkVtYWlsXG4gICAgICAgIH1cbiAgICAgIH0pLnZhbGlkYXRlKHsgZW1haWwgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsIGUubWVzc2FnZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuXG5cdEFjY291bnRzLm9uQ3JlYXRlVXNlcigob3B0aW9ucywgdXNlcikgPT4ge1xuXHRcdHVzZXIucHJvZmlsZSA9IHtyb2xlOiBvcHRpb25zLnByb2ZpbGUucm9sZX1cblx0XHRyZXR1cm4gdXNlclxuXHR9KVxuXG5cbn0pO1xuIl19
